-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Jeu 05 Mars 2020 à 22:19
-- Version du serveur :  8.0.19-0ubuntu0.19.10.3
-- Version de PHP :  7.2.24-0ubuntu0.19.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `wp_brasos`
--

-- --------------------------------------------------------

--
-- Structure de la table `wp_advsh`
--

CREATE TABLE `wp_advsh` (
  `id` int NOT NULL,
  `db` varchar(50) NOT NULL,
  `tables` varchar(30) NOT NULL,
  `nameField` varchar(30) NOT NULL,
  `colonnesWhere` text NOT NULL,
  `typeSearch` varchar(8) NOT NULL,
  `encoding` varchar(25) NOT NULL,
  `exactSearch` tinyint(1) NOT NULL,
  `accents` tinyint(1) NOT NULL,
  `exclusionWords` text,
  `stopWords` tinyint(1) NOT NULL,
  `nbResultsOK` tinyint(1) NOT NULL,
  `NumberOK` tinyint(1) NOT NULL,
  `NumberPerPage` int DEFAULT NULL,
  `idform` varchar(200) DEFAULT NULL,
  `placeholder` varchar(200) DEFAULT NULL,
  `Style` varchar(10) NOT NULL,
  `formatageDate` varchar(25) DEFAULT NULL,
  `DateOK` tinyint(1) NOT NULL,
  `AuthorOK` tinyint(1) NOT NULL,
  `CategoryOK` tinyint(1) NOT NULL,
  `TitleOK` tinyint(1) NOT NULL,
  `ArticleOK` varchar(12) NOT NULL,
  `CommentOK` tinyint(1) NOT NULL,
  `ImageOK` tinyint(1) NOT NULL,
  `BlocOrder` varchar(10) NOT NULL,
  `strongWords` varchar(10) NOT NULL,
  `OrderOK` tinyint(1) NOT NULL,
  `OrderColumn` varchar(25) NOT NULL,
  `AscDesc` varchar(4) NOT NULL,
  `AlgoOK` tinyint(1) NOT NULL,
  `paginationActive` tinyint(1) NOT NULL,
  `paginationStyle` varchar(30) NOT NULL,
  `paginationFirstLast` tinyint(1) NOT NULL,
  `paginationPrevNext` tinyint(1) NOT NULL,
  `paginationFirstPage` varchar(50) NOT NULL,
  `paginationLastPage` varchar(50) NOT NULL,
  `paginationPrevText` varchar(50) NOT NULL,
  `paginationNextText` varchar(50) NOT NULL,
  `paginationType` varchar(50) NOT NULL,
  `paginationNbLimit` int NOT NULL,
  `paginationDuration` int NOT NULL,
  `paginationText` varchar(250) NOT NULL,
  `postType` varchar(8) NOT NULL,
  `categories` text,
  `ResultText` text,
  `ErrorText` text,
  `autoCompleteActive` tinyint(1) NOT NULL,
  `autoCompleteSelector` varchar(50) NOT NULL,
  `autoCompleteAutofocus` tinyint(1) NOT NULL,
  `autoCompleteType` tinyint DEFAULT NULL,
  `autoCompleteNumber` tinyint DEFAULT NULL,
  `autoCompleteTypeSuggest` tinyint(1) NOT NULL,
  `autoCompleteCreate` tinyint(1) NOT NULL,
  `autoCompleteTable` varchar(50) NOT NULL,
  `autoCompleteColumn` varchar(50) NOT NULL,
  `autoCompleteGenerate` tinyint(1) NOT NULL,
  `autoCompleteSizeMin` tinyint DEFAULT NULL,
  `autoCorrectActive` tinyint(1) NOT NULL,
  `autoCorrectType` tinyint DEFAULT NULL,
  `autoCorrectMethod` tinyint(1) NOT NULL,
  `autoCorrectString` text NOT NULL,
  `autoCorrectCreate` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `wp_advsh`
--

INSERT INTO `wp_advsh` (`id`, `db`, `tables`, `nameField`, `colonnesWhere`, `typeSearch`, `encoding`, `exactSearch`, `accents`, `exclusionWords`, `stopWords`, `nbResultsOK`, `NumberOK`, `NumberPerPage`, `idform`, `placeholder`, `Style`, `formatageDate`, `DateOK`, `AuthorOK`, `CategoryOK`, `TitleOK`, `ArticleOK`, `CommentOK`, `ImageOK`, `BlocOrder`, `strongWords`, `OrderOK`, `OrderColumn`, `AscDesc`, `AlgoOK`, `paginationActive`, `paginationStyle`, `paginationFirstLast`, `paginationPrevNext`, `paginationFirstPage`, `paginationLastPage`, `paginationPrevText`, `paginationNextText`, `paginationType`, `paginationNbLimit`, `paginationDuration`, `paginationText`, `postType`, `categories`, `ResultText`, `ErrorText`, `autoCompleteActive`, `autoCompleteSelector`, `autoCompleteAutofocus`, `autoCompleteType`, `autoCompleteNumber`, `autoCompleteTypeSuggest`, `autoCompleteCreate`, `autoCompleteTable`, `autoCompleteColumn`, `autoCompleteGenerate`, `autoCompleteSizeMin`, `autoCorrectActive`, `autoCorrectType`, `autoCorrectMethod`, `autoCorrectString`, `autoCorrectCreate`) VALUES
(1, 'wp_brasos', 'wp_posts', 's', 'post_title, post_content, post_excerpt', 'REGEXP', 'utf-8', 1, 0, '1', 1, 0, 1, 3, 's', '', 'aucun', 'j F Y', 1, 1, 1, 1, 'aucun', 1, 0, 'D-A-C', 'exact', 1, 'ID', 'ASC', 0, 1, 'aucun', 1, 1, 'Première page', 'Dernière page', '&laquo; Précédent', 'Suivant &raquo;', 'trigger', 5, 300, 'Afficher plus de résultats', 'post', 'a:1:{i:0;s:6:\"toutes\";}', 'Résultats de la recherche :', 'Aucun résultat, veuillez effectuer une autre recherche !', 1, '.search-field', 0, 0, 5, 1, 0, 'wp_autosuggest', 'words', 1, 2, 1, 2, 1, 'Tentez avec une autre orthographe : ', 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_autosuggest`
--

CREATE TABLE `wp_autosuggest` (
  `idindex` int NOT NULL,
  `words` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `wp_commentmeta`
--

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `comment_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Structure de la table `wp_comments`
--

CREATE TABLE `wp_comments` (
  `comment_ID` bigint UNSIGNED NOT NULL,
  `comment_post_ID` bigint UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_comments`
--

INSERT INTO `wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Um comentarista do WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2020-02-07 15:10:19', '2020-02-07 18:10:19', 'Olá, isso é um comentário.\nPara começar a moderar, editar e excluir comentários, visite a tela de Comentários no painel.\nAvatares de comentaristas vêm a partir do <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_links`
--

CREATE TABLE `wp_links` (
  `link_id` bigint UNSIGNED NOT NULL,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Structure de la table `wp_options`
--

CREATE TABLE `wp_options` (
  `option_id` bigint UNSIGNED NOT NULL,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_options`
--

INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/Agencia-Fazer/Brasos/wp', 'yes'),
(2, 'home', 'http://localhost/Agencia-Fazer/Brasos/', 'yes'),
(3, 'blogname', 'Brasos', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '1', 'yes'),
(6, 'admin_email', 'helio-cruz@hotmail.com', 'yes'),
(7, 'start_of_week', '0', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j \\d\\e F \\d\\e Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'j \\d\\e F \\d\\e Y, H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:103:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:45:\"language_switcher/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:55:\"language_switcher/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:75:\"language_switcher/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"language_switcher/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:70:\"language_switcher/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:51:\"language_switcher/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:34:\"language_switcher/([^/]+)/embed/?$\";s:50:\"index.php?language_switcher=$matches[1]&embed=true\";s:38:\"language_switcher/([^/]+)/trackback/?$\";s:44:\"index.php?language_switcher=$matches[1]&tb=1\";s:46:\"language_switcher/([^/]+)/page/?([0-9]{1,})/?$\";s:57:\"index.php?language_switcher=$matches[1]&paged=$matches[2]\";s:53:\"language_switcher/([^/]+)/comment-page-([0-9]{1,})/?$\";s:57:\"index.php?language_switcher=$matches[1]&cpage=$matches[2]\";s:42:\"language_switcher/([^/]+)(?:/([0-9]+))?/?$\";s:56:\"index.php?language_switcher=$matches[1]&page=$matches[2]\";s:34:\"language_switcher/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:44:\"language_switcher/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:64:\"language_switcher/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"language_switcher/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:59:\"language_switcher/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:40:\"language_switcher/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:26:\"brasos/brasos.settings.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:37:\"translatepress-multilingual/index.php\";i:3;s:41:\"wp-advanced-search/WP-Advanced-Search.php\";i:4;s:29:\"wp-mail-smtp/wp_mail_smtp.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'brasos', 'yes'),
(41, 'stylesheet', 'brasos', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '44719', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', 'America/Sao_Paulo', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '1', 'yes'),
(93, 'admin_email_lifespan', '1583609914', 'yes'),
(94, 'initial_db_version', '45805', 'yes'),
(95, 'wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(96, 'fresh_site', '0', 'yes'),
(97, 'WPLANG', 'pt_BR', 'yes'),
(98, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'widget_archives', 'a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(102, 'widget_meta', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'sidebars_widgets', 'a:2:{s:19:\"wp_inactive_widgets\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}', 'yes'),
(104, 'cron', 'a:6:{i:1583446219;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1583475019;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1583518219;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1583518246;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1583518248;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(105, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(112, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(113, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(115, 'recovery_keys', 'a:0:{}', 'yes'),
(119, 'theme_mods_twentytwenty', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1581099066;s:4:\"data\";a:3:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}}}}', 'yes'),
(146, 'recently_activated', 'a:1:{s:35:\"empty-wp-plugin/empty-wp-plugin.php\";i:1583094135;}', 'yes'),
(147, 'current_theme', 'Brasos', 'yes'),
(148, 'theme_mods_brasos', 'a:20:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:17:\"brasos_bg_slide_1\";s:76:\"http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.1-scaled.jpg\";s:17:\"brasos_bg_slide_2\";s:76:\"http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.2-scaled.jpg\";s:17:\"brasos_bg_slide_3\";s:76:\"http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.3-scaled.jpg\";s:24:\"brasos_call_to_content-1\";s:138:\"Cursos pré-simpósio de Injeções intra-articulares guiadas por Ultrassonografia em Osteoartrite do Joelho,\n Quadril, Ombro e Tornozelo.\";s:24:\"brasos_call_to_content-2\";s:237:\"Tratamento por injeções intra-articulares: Ácido Hialurônico em diferentes pesos moleculares, Hialuronato e Ácido Hialurônico associado à outras moléculas Glicocorticóides regulares e de liberação prolongada. Novas\n moléculas\";s:24:\"brasos_call_to_content-3\";s:272:\"Fatores que potencializam as infiltrações articulares: Colágenos (Natural –Hidrolisados –\nUltra-hidrolisados) - Suplementos Adjuvantes – Sysadoa (Sulfato de Condroitina e Glicosamina de alta\nqualidade – Curcumina – Diacereína) – Prebióticos - Probióticos\";s:24:\"brasos_call_to_content-4\";s:100:\" Tratamento por infiltração na Rede Pública, é possível? Exemplo do municipio de Caraguatatuba.\";s:24:\"brasos_call_to_content-5\";s:64:\"Viscossuplementação na Agência Nacional de Saúde Suplementar\";s:24:\"brasos_call_to_content-6\";s:39:\"Viscossuplementação e Farmacoeconomia\";s:24:\"brasos_call_to_content-7\";s:90:\" Consenso Brasileiro sobre Viscossuplementação de Joelho – COBRAVI J: Qual seu legado?\";s:24:\"brasos_call_to_content-8\";s:90:\" Consenso Brasileiro sobre Viscossuplementação de Quadril – COBRAVI Q: Apresentação.\";s:24:\"brasos_call_to_content-9\";s:86:\" Consenso Brasileiro sobre Viscossuplementação de Ombro – COBRAVI O: Realização.\";s:25:\"brasos_call_to_content-10\";s:42:\"Uso do Ácido Hialurônico em partes moles\";s:25:\"brasos_call_to_content-11\";s:101:\"Fatores que potencializam as infiltrações articulares: Colágenos - Suplmentos Adjuvantes - Sysadoa\";s:25:\"brasos_call_to_content-12\";s:214:\"            Novas moléculas no tratamento por infiltração: BM7 - Lubricin - LMWF-5A - betaNGFantibody - Interleukin 1\n            antagonist and antibody receptor - TPX100MEB - PTHrP - TGF-B inhibitor - IARArORa\";s:25:\"brasos_call_to_content-13\";s:76:\"Tratamento intra-articular e combinação de moléculas: riscos e beneficios\";s:25:\"brasos_call_to_content-14\";s:209:\" Tratamento biológico intra-articular: PRP, PRF, CÉLULAS TRONCO – aspirado de medula óssea; fatores de\n            crescimento; células mesenquimais e regenerativas autólogas derivadas do tecido adiposo\";}', 'yes'),
(149, 'theme_switched', '', 'yes'),
(163, '_site_transient_timeout_browser_75956858e205cfb2124d15110fcda3ea', '1583691386', 'no'),
(164, '_site_transient_browser_75956858e205cfb2124d15110fcda3ea', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"80.0.3987.87\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(165, '_site_transient_timeout_php_check_fda0dab287a24738d56eb93369e13dcf', '1583691387', 'no'),
(166, '_site_transient_php_check_fda0dab287a24738d56eb93369e13dcf', 'a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(181, 'db_upgraded', '', 'yes'),
(198, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}', 'yes'),
(201, 'trp_settings', 'a:12:{s:16:\"default-language\";s:5:\"pt_BR\";s:17:\"publish-languages\";a:2:{i:0;s:5:\"pt_BR\";i:1;s:5:\"en_US\";}s:21:\"translation-languages\";a:2:{i:0;s:5:\"pt_BR\";i:1;s:5:\"en_US\";}s:9:\"url-slugs\";a:2:{s:5:\"pt_BR\";s:5:\"pt_br\";s:5:\"en_US\";s:2:\"en\";}s:22:\"native_or_english_name\";s:12:\"english_name\";s:36:\"add-subdirectory-to-default-language\";s:2:\"no\";s:30:\"force-language-to-custom-links\";s:3:\"yes\";s:17:\"shortcode-options\";s:10:\"only-flags\";s:12:\"menu-options\";s:10:\"only-flags\";s:15:\"floater-options\";s:16:\"flags-full-names\";s:16:\"floater-position\";s:12:\"bottom-right\";s:14:\"trp-ls-floater\";s:2:\"no\";}', 'yes'),
(202, 'trp_plugin_version', '1.6.7', 'yes'),
(225, 'recovery_mode_email_last_sent', '1583102820', 'yes'),
(266, 'new_admin_email', 'helio-cruz@hotmail.com', 'yes'),
(317, '_transient_timeout_plugin_slugs', '1583479544', 'no'),
(318, '_transient_plugin_slugs', 'a:5:{i:0;s:26:\"brasos/brasos.settings.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:37:\"translatepress-multilingual/index.php\";i:3;s:41:\"wp-advanced-search/WP-Advanced-Search.php\";i:4;s:29:\"wp-mail-smtp/wp_mail_smtp.php\";}', 'no'),
(319, 'wp_mail_smtp_initial_version', '1.8.1', 'no'),
(320, 'wp_mail_smtp_version', '1.8.1', 'no'),
(321, 'wp_mail_smtp', 'a:2:{s:4:\"mail\";a:6:{s:10:\"from_email\";s:22:\"helio-cruz@hotmail.com\";s:9:\"from_name\";s:6:\"Brasos\";s:6:\"mailer\";s:4:\"mail\";s:11:\"return_path\";b:0;s:16:\"from_email_force\";b:0;s:15:\"from_name_force\";b:0;}s:4:\"smtp\";a:2:{s:7:\"autotls\";b:1;s:4:\"auth\";b:1;}}', 'no'),
(337, 'wp_advanced_search_version', '3.3.3', 'no'),
(338, 'category_children', 'a:0:{}', 'yes'),
(349, 'wp_mail_smtp_debug', 'a:1:{i:0;s:110:\"Mailer: Default (none)\r\nPHPMailer was able to connect to SMTP server but failed while trying to send an email.\";}', 'no'),
(357, '_site_transient_timeout_browser_9ce6bdcddb978c9e6e5868f003c3031a', '1583974432', 'no'),
(358, '_site_transient_browser_9ce6bdcddb978c9e6e5868f003c3031a', 'a:10:{s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:12:\"78.0.3904.87\";s:8:\"platform\";s:5:\"Linux\";s:10:\"update_url\";s:29:\"https://www.google.com/chrome\";s:7:\"img_src\";s:43:\"http://s.w.org/images/browsers/chrome.png?1\";s:11:\"img_src_ssl\";s:44:\"https://s.w.org/images/browsers/chrome.png?1\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(359, '_site_transient_timeout_php_check_fbcea1b922795623e1209601d39ea27d', '1583974433', 'no'),
(360, '_site_transient_php_check_fbcea1b922795623e1209601d39ea27d', 'a:5:{s:19:\"recommended_version\";s:3:\"7.3\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:1;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}', 'no'),
(361, 'can_compress_scripts', '0', 'no'),
(375, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.1.6\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";d:1583382344;s:7:\"version\";s:5:\"5.1.6\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(388, '_site_transient_timeout_theme_roots', '1583435289', 'no'),
(389, '_site_transient_theme_roots', 'a:3:{s:6:\"brasos\";s:7:\"/themes\";s:14:\"twentynineteen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";}', 'no'),
(391, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:5:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:65:\"https://downloads.wordpress.org/release/pt_BR/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"pt_BR\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:65:\"https://downloads.wordpress.org/release/pt_BR/wordpress-5.3.2.zip\";s:10:\"no_content\";b:0;s:11:\"new_bundled\";b:0;s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.3.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.3.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.3.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.3.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.3.2\";s:7:\"version\";s:5:\"5.3.2\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:3;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.5.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.2.5.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.2.5-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.2.5-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.2.5\";s:7:\"version\";s:5:\"5.2.5\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:4;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.4-new-bundled.zip\";s:7:\"partial\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.1.4-partial-1.zip\";s:8:\"rollback\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.4-rollback-1.zip\";}s:7:\"current\";s:5:\"5.1.4\";s:7:\"version\";s:5:\"5.1.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.3\";s:15:\"partial_version\";s:5:\"5.1.1\";s:9:\"new_files\";s:0:\"\";}}s:12:\"last_checked\";i:1583433492;s:15:\"version_checked\";s:5:\"5.1.1\";s:12:\"translations\";a:0:{}}', 'no'),
(392, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1583433493;s:7:\"checked\";a:3:{s:6:\"brasos\";s:5:\"1.0.0\";s:14:\"twentynineteen\";s:3:\"1.4\";s:12:\"twentytwenty\";s:3:\"1.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}', 'no'),
(393, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1583433494;s:7:\"checked\";a:5:{s:26:\"brasos/brasos.settings.php\";s:3:\"0.1\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.1.6\";s:37:\"translatepress-multilingual/index.php\";s:5:\"1.6.7\";s:41:\"wp-advanced-search/WP-Advanced-Search.php\";s:5:\"3.3.3\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:5:\"1.8.1\";}s:8:\"response\";a:1:{s:41:\"wp-advanced-search/WP-Advanced-Search.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:32:\"w.org/plugins/wp-advanced-search\";s:4:\"slug\";s:18:\"wp-advanced-search\";s:6:\"plugin\";s:41:\"wp-advanced-search/WP-Advanced-Search.php\";s:11:\"new_version\";s:5:\"3.3.4\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/wp-advanced-search/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/wp-advanced-search.3.3.4.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/wp-advanced-search/assets/icon-256x256.png?rev=1004490\";s:2:\"1x\";s:71:\"https://ps.w.org/wp-advanced-search/assets/icon-256x256.png?rev=1004490\";}s:7:\"banners\";a:0:{}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:5:\"5.2.5\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:1:{i:0;a:7:{s:4:\"type\";s:6:\"plugin\";s:4:\"slug\";s:14:\"contact-form-7\";s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.1.6\";s:7:\"updated\";s:19:\"2019-11-20 01:10:24\";s:7:\"package\";s:81:\"https://downloads.wordpress.org/translation/plugin/contact-form-7/5.1.6/pt_BR.zip\";s:10:\"autoupdate\";b:1;}}s:9:\"no_update\";a:3:{s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.1.6\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.1.6.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:37:\"translatepress-multilingual/index.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:41:\"w.org/plugins/translatepress-multilingual\";s:4:\"slug\";s:27:\"translatepress-multilingual\";s:6:\"plugin\";s:37:\"translatepress-multilingual/index.php\";s:11:\"new_version\";s:5:\"1.6.7\";s:3:\"url\";s:58:\"https://wordpress.org/plugins/translatepress-multilingual/\";s:7:\"package\";s:76:\"https://downloads.wordpress.org/plugin/translatepress-multilingual.1.6.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:80:\"https://ps.w.org/translatepress-multilingual/assets/icon-256x256.png?rev=1722670\";s:2:\"1x\";s:80:\"https://ps.w.org/translatepress-multilingual/assets/icon-128x128.png?rev=1722670\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:83:\"https://ps.w.org/translatepress-multilingual/assets/banner-1544x500.png?rev=1722670\";s:2:\"1x\";s:82:\"https://ps.w.org/translatepress-multilingual/assets/banner-772x250.png?rev=1722670\";}s:11:\"banners_rtl\";a:0:{}}s:29:\"wp-mail-smtp/wp_mail_smtp.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:26:\"w.org/plugins/wp-mail-smtp\";s:4:\"slug\";s:12:\"wp-mail-smtp\";s:6:\"plugin\";s:29:\"wp-mail-smtp/wp_mail_smtp.php\";s:11:\"new_version\";s:5:\"1.8.1\";s:3:\"url\";s:43:\"https://wordpress.org/plugins/wp-mail-smtp/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/plugin/wp-mail-smtp.1.8.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-256x256.png?rev=1755440\";s:2:\"1x\";s:65:\"https://ps.w.org/wp-mail-smtp/assets/icon-128x128.png?rev=1755440\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/wp-mail-smtp/assets/banner-1544x500.png?rev=2120094\";s:2:\"1x\";s:67:\"https://ps.w.org/wp-mail-smtp/assets/banner-772x250.png?rev=2120094\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(394, '_site_transient_timeout_available_translations', '1583445278', 'no');
INSERT INTO `wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(395, '_site_transient_available_translations', 'a:117:{s:2:\"af\";a:8:{s:8:\"language\";s:2:\"af\";s:7:\"version\";s:5:\"5.0.8\";s:7:\"updated\";s:19:\"2019-10-23 12:40:19\";s:12:\"english_name\";s:9:\"Afrikaans\";s:11:\"native_name\";s:9:\"Afrikaans\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.0.8/af.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"af\";i:2;s:3:\"afr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Gaan voort\";}}s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-09-03 09:41:19\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:3:\"ary\";a:8:{s:8:\"language\";s:3:\"ary\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:42:35\";s:12:\"english_name\";s:15:\"Moroccan Arabic\";s:11:\"native_name\";s:31:\"العربية المغربية\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.7/ary.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:3;s:3:\"ary\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"as\";a:8:{s:8:\"language\";s:2:\"as\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-22 18:59:07\";s:12:\"english_name\";s:8:\"Assamese\";s:11:\"native_name\";s:21:\"অসমীয়া\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/as.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"as\";i:2;s:3:\"asm\";i:3;s:3:\"asm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:3:\"azb\";a:8:{s:8:\"language\";s:3:\"azb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-12 20:34:31\";s:12:\"english_name\";s:17:\"South Azerbaijani\";s:11:\"native_name\";s:29:\"گؤنئی آذربایجان\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/azb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:3;s:3:\"azb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-06 00:09:27\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:3:\"bel\";a:8:{s:8:\"language\";s:3:\"bel\";s:7:\"version\";s:6:\"4.9.13\";s:7:\"updated\";s:19:\"2019-10-29 07:54:22\";s:12:\"english_name\";s:10:\"Belarusian\";s:11:\"native_name\";s:29:\"Беларуская мова\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/translation/core/4.9.13/bel.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"be\";i:2;s:3:\"bel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Працягнуць\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-08-06 20:04:09\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bn_BD\";a:8:{s:8:\"language\";s:5:\"bn_BD\";s:7:\"version\";s:6:\"4.8.12\";s:7:\"updated\";s:19:\"2017-10-01 12:57:10\";s:12:\"english_name\";s:20:\"Bengali (Bangladesh)\";s:11:\"native_name\";s:15:\"বাংলা\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.8.12/bn_BD.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"bn\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:23:\"এগিয়ে চল.\";}}s:2:\"bo\";a:8:{s:8:\"language\";s:2:\"bo\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-22 01:54:56\";s:12:\"english_name\";s:7:\"Tibetan\";s:11:\"native_name\";s:21:\"བོད་ཡིག\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/bo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bo\";i:2;s:3:\"tib\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"མུ་མཐུད།\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-06-12 06:34:12\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-03 19:45:46\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:3:\"ceb\";a:8:{s:8:\"language\";s:3:\"ceb\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-02 17:25:51\";s:12:\"english_name\";s:7:\"Cebuano\";s:11:\"native_name\";s:7:\"Cebuano\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/ceb.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"ceb\";i:3;s:3:\"ceb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Padayun\";}}s:5:\"cs_CZ\";a:8:{s:8:\"language\";s:5:\"cs_CZ\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-02 05:02:44\";s:12:\"english_name\";s:5:\"Czech\";s:11:\"native_name\";s:9:\"Čeština\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/cs_CZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cs\";i:2;s:3:\"ces\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:11:\"Pokračovat\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-08 13:44:30\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-25 20:13:18\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:12:\"de_DE_formal\";a:8:{s:8:\"language\";s:12:\"de_DE_formal\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-28 20:52:46\";s:12:\"english_name\";s:15:\"German (Formal)\";s:11:\"native_name\";s:13:\"Deutsch (Sie)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.1.1/de_DE_formal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-28 20:52:36\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:14:\"de_CH_informal\";a:8:{s:8:\"language\";s:14:\"de_CH_informal\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-29 19:06:37\";s:12:\"english_name\";s:30:\"German (Switzerland, Informal)\";s:11:\"native_name\";s:21:\"Deutsch (Schweiz, Du)\";s:7:\"package\";s:73:\"https://downloads.wordpress.org/translation/core/5.1.1/de_CH_informal.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-29 19:06:10\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_AT\";a:8:{s:8:\"language\";s:5:\"de_AT\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-12 05:45:50\";s:12:\"english_name\";s:16:\"German (Austria)\";s:11:\"native_name\";s:21:\"Deutsch (Österreich)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/de_AT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Weiter\";}}s:3:\"dzo\";a:8:{s:8:\"language\";s:3:\"dzo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-06-29 08:59:03\";s:12:\"english_name\";s:8:\"Dzongkha\";s:11:\"native_name\";s:18:\"རྫོང་ཁ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/dzo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"dz\";i:2;s:3:\"dzo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-04 20:40:40\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_ZA\";a:8:{s:8:\"language\";s:5:\"en_ZA\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-06-06 15:48:01\";s:12:\"english_name\";s:22:\"English (South Africa)\";s:11:\"native_name\";s:22:\"English (South Africa)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/en_ZA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_NZ\";a:8:{s:8:\"language\";s:5:\"en_NZ\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-07 23:32:35\";s:12:\"english_name\";s:21:\"English (New Zealand)\";s:11:\"native_name\";s:21:\"English (New Zealand)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/en_NZ.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-06-06 15:48:10\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-25 23:19:50\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-06-06 15:39:26\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-21 14:53:06\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_VE\";a:8:{s:8:\"language\";s:5:\"es_VE\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-28 14:18:18\";s:12:\"english_name\";s:19:\"Spanish (Venezuela)\";s:11:\"native_name\";s:21:\"Español de Venezuela\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/es_VE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_AR\";a:8:{s:8:\"language\";s:5:\"es_AR\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-12 02:56:56\";s:12:\"english_name\";s:19:\"Spanish (Argentina)\";s:11:\"native_name\";s:21:\"Español de Argentina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/es_AR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-24 08:04:25\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/es_ES.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_GT\";a:8:{s:8:\"language\";s:5:\"es_GT\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-03-02 06:35:01\";s:12:\"english_name\";s:19:\"Spanish (Guatemala)\";s:11:\"native_name\";s:21:\"Español de Guatemala\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1/es_GT.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"5.0.8\";s:7:\"updated\";s:19:\"2019-11-12 17:58:51\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.0.8/es_MX.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CR\";a:8:{s:8:\"language\";s:5:\"es_CR\";s:7:\"version\";s:3:\"5.0\";s:7:\"updated\";s:19:\"2018-12-06 21:26:01\";s:12:\"english_name\";s:20:\"Spanish (Costa Rica)\";s:11:\"native_name\";s:22:\"Español de Costa Rica\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.0/es_CR.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CO\";a:8:{s:8:\"language\";s:5:\"es_CO\";s:7:\"version\";s:6:\"4.9.13\";s:7:\"updated\";s:19:\"2019-05-23 02:23:28\";s:12:\"english_name\";s:18:\"Spanish (Colombia)\";s:11:\"native_name\";s:20:\"Español de Colombia\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.9.13/es_CO.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-09 09:36:22\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/es_PE.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-07 16:34:55\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/es_CL.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"es\";i:2;s:3:\"spa\";i:3;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"et\";a:8:{s:8:\"language\";s:2:\"et\";s:7:\"version\";s:9:\"5.0-beta3\";s:7:\"updated\";s:19:\"2018-11-28 16:04:33\";s:12:\"english_name\";s:8:\"Estonian\";s:11:\"native_name\";s:5:\"Eesti\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/5.0-beta3/et.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"et\";i:2;s:3:\"est\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Jätka\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2017-12-09 21:12:23\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-14 11:16:45\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-29 13:01:02\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-17 04:59:43\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_BE\";a:8:{s:8:\"language\";s:5:\"fr_BE\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-01-31 11:16:06\";s:12:\"english_name\";s:16:\"French (Belgium)\";s:11:\"native_name\";s:21:\"Français de Belgique\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/fr_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:5:\"fr_CA\";a:8:{s:8:\"language\";s:5:\"fr_CA\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-18 01:20:08\";s:12:\"english_name\";s:15:\"French (Canada)\";s:11:\"native_name\";s:19:\"Français du Canada\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/fr_CA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fr\";i:2;s:3:\"fra\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:3:\"fur\";a:8:{s:8:\"language\";s:3:\"fur\";s:7:\"version\";s:5:\"4.8.6\";s:7:\"updated\";s:19:\"2018-01-29 17:32:35\";s:12:\"english_name\";s:8:\"Friulian\";s:11:\"native_name\";s:8:\"Friulian\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.6/fur.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"fur\";i:3;s:3:\"fur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-08-23 17:41:37\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-08 23:32:17\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"gu\";a:8:{s:8:\"language\";s:2:\"gu\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-14 12:33:48\";s:12:\"english_name\";s:8:\"Gujarati\";s:11:\"native_name\";s:21:\"ગુજરાતી\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.8/gu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gu\";i:2;s:3:\"guj\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"ચાલુ રાખવું\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.4.2\";s:7:\"updated\";s:19:\"2015-12-05 00:59:09\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.4.2/haz.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-09 19:18:04\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:5:\"hi_IN\";a:8:{s:8:\"language\";s:5:\"hi_IN\";s:7:\"version\";s:5:\"4.9.7\";s:7:\"updated\";s:19:\"2018-06-17 09:33:44\";s:12:\"english_name\";s:5:\"Hindi\";s:11:\"native_name\";s:18:\"हिन्दी\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.7/hi_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hi\";i:2;s:3:\"hin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"जारी\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-18 07:37:51\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-19 14:36:40\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:2:\"hy\";a:8:{s:8:\"language\";s:2:\"hy\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-03 16:21:10\";s:12:\"english_name\";s:8:\"Armenian\";s:11:\"native_name\";s:14:\"Հայերեն\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/hy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hy\";i:2;s:3:\"hye\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Շարունակել\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"5.0.8\";s:7:\"updated\";s:19:\"2019-09-24 03:05:30\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.0.8/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:6:\"4.7.11\";s:7:\"updated\";s:19:\"2018-09-20 11:13:37\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.7.11/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-09-02 18:22:16\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-11 20:53:19\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"jv_ID\";a:8:{s:8:\"language\";s:5:\"jv_ID\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-24 13:53:29\";s:12:\"english_name\";s:8:\"Javanese\";s:11:\"native_name\";s:9:\"Basa Jawa\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/jv_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"jv\";i:2;s:3:\"jav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nutugne\";}}s:5:\"ka_GE\";a:8:{s:8:\"language\";s:5:\"ka_GE\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-02-21 08:17:32\";s:12:\"english_name\";s:8:\"Georgian\";s:11:\"native_name\";s:21:\"ქართული\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1/ka_GE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ka\";i:2;s:3:\"kat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"გაგრძელება\";}}s:3:\"kab\";a:8:{s:8:\"language\";s:3:\"kab\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-09-21 14:15:57\";s:12:\"english_name\";s:6:\"Kabyle\";s:11:\"native_name\";s:9:\"Taqbaylit\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.8/kab.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"kab\";i:3;s:3:\"kab\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"kk\";a:8:{s:8:\"language\";s:2:\"kk\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-12 08:08:32\";s:12:\"english_name\";s:6:\"Kazakh\";s:11:\"native_name\";s:19:\"Қазақ тілі\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.9.5/kk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kk\";i:2;s:3:\"kaz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Жалғастыру\";}}s:2:\"km\";a:8:{s:8:\"language\";s:2:\"km\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-09 07:34:10\";s:12:\"english_name\";s:5:\"Khmer\";s:11:\"native_name\";s:27:\"ភាសាខ្មែរ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.0.3/km.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"km\";i:2;s:3:\"khm\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"បន្ត\";}}s:2:\"kn\";a:8:{s:8:\"language\";s:2:\"kn\";s:7:\"version\";s:6:\"4.9.13\";s:7:\"updated\";s:19:\"2019-12-04 12:22:34\";s:12:\"english_name\";s:7:\"Kannada\";s:11:\"native_name\";s:15:\"ಕನ್ನಡ\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.13/kn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"kn\";i:2;s:3:\"kan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"ಮುಂದುವರೆಸಿ\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-08-27 04:34:18\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:3:\"ckb\";a:8:{s:8:\"language\";s:3:\"ckb\";s:7:\"version\";s:5:\"4.9.9\";s:7:\"updated\";s:19:\"2018-12-18 14:32:44\";s:12:\"english_name\";s:16:\"Kurdish (Sorani)\";s:11:\"native_name\";s:13:\"كوردی‎\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.9.9/ckb.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ku\";i:3;s:3:\"ckb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"به‌رده‌وام به‌\";}}s:2:\"lo\";a:8:{s:8:\"language\";s:2:\"lo\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 09:59:23\";s:12:\"english_name\";s:3:\"Lao\";s:11:\"native_name\";s:21:\"ພາສາລາວ\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/lo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lo\";i:2;s:3:\"lao\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"ຕໍ່\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-08-27 09:35:04\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:2:\"lv\";a:8:{s:8:\"language\";s:2:\"lv\";s:7:\"version\";s:6:\"4.7.15\";s:7:\"updated\";s:19:\"2019-05-10 10:24:08\";s:12:\"english_name\";s:7:\"Latvian\";s:11:\"native_name\";s:16:\"Latviešu valoda\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.15/lv.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lv\";i:2;s:3:\"lav\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Turpināt\";}}s:5:\"mk_MK\";a:8:{s:8:\"language\";s:5:\"mk_MK\";s:7:\"version\";s:5:\"4.7.7\";s:7:\"updated\";s:19:\"2017-01-26 15:54:41\";s:12:\"english_name\";s:10:\"Macedonian\";s:11:\"native_name\";s:31:\"Македонски јазик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.7/mk_MK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mk\";i:2;s:3:\"mkd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Продолжи\";}}s:5:\"ml_IN\";a:8:{s:8:\"language\";s:5:\"ml_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:43:32\";s:12:\"english_name\";s:9:\"Malayalam\";s:11:\"native_name\";s:18:\"മലയാളം\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ml_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ml\";i:2;s:3:\"mal\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:18:\"തുടരുക\";}}s:2:\"mn\";a:8:{s:8:\"language\";s:2:\"mn\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-12 07:29:35\";s:12:\"english_name\";s:9:\"Mongolian\";s:11:\"native_name\";s:12:\"Монгол\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/mn.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mn\";i:2;s:3:\"mon\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"Үргэлжлүүлэх\";}}s:2:\"mr\";a:8:{s:8:\"language\";s:2:\"mr\";s:7:\"version\";s:6:\"4.8.11\";s:7:\"updated\";s:19:\"2018-02-13 07:38:55\";s:12:\"english_name\";s:7:\"Marathi\";s:11:\"native_name\";s:15:\"मराठी\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.11/mr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"mr\";i:2;s:3:\"mar\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"सुरु ठेवा\";}}s:5:\"ms_MY\";a:8:{s:8:\"language\";s:5:\"ms_MY\";s:7:\"version\";s:5:\"4.9.8\";s:7:\"updated\";s:19:\"2018-08-30 20:27:25\";s:12:\"english_name\";s:5:\"Malay\";s:11:\"native_name\";s:13:\"Bahasa Melayu\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.8/ms_MY.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ms\";i:2;s:3:\"msa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Teruskan\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:65:\"https://downloads.wordpress.org/translation/core/4.1.20/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-29 18:32:50\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"ne_NP\";a:8:{s:8:\"language\";s:5:\"ne_NP\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-03-27 10:30:26\";s:12:\"english_name\";s:6:\"Nepali\";s:11:\"native_name\";s:18:\"नेपाली\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ne_NP.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ne\";i:2;s:3:\"nep\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:31:\"जारीराख्नु \";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-12 08:44:59\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nl_BE\";a:8:{s:8:\"language\";s:5:\"nl_BE\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-28 13:59:03\";s:12:\"english_name\";s:15:\"Dutch (Belgium)\";s:11:\"native_name\";s:20:\"Nederlands (België)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/nl_BE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:12:\"nl_NL_formal\";a:8:{s:8:\"language\";s:12:\"nl_NL_formal\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-23 09:40:21\";s:12:\"english_name\";s:14:\"Dutch (Formal)\";s:11:\"native_name\";s:20:\"Nederlands (Formeel)\";s:7:\"package\";s:71:\"https://downloads.wordpress.org/translation/core/5.1.1/nl_NL_formal.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-09 16:36:42\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.8.3\";s:7:\"updated\";s:19:\"2017-08-25 10:03:08\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.8.3/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pa_IN\";a:8:{s:8:\"language\";s:5:\"pa_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-16 05:19:43\";s:12:\"english_name\";s:7:\"Punjabi\";s:11:\"native_name\";s:18:\"ਪੰਜਾਬੀ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/pa_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pa\";i:2;s:3:\"pan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:25:\"ਜਾਰੀ ਰੱਖੋ\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-13 06:39:07\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:6:\"4.1.20\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.20/ps.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ps\";i:2;s:3:\"pus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-02 08:02:12\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-13 17:59:01\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_AO\";a:8:{s:8:\"language\";s:5:\"pt_AO\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-17 07:59:20\";s:12:\"english_name\";s:19:\"Portuguese (Angola)\";s:11:\"native_name\";s:20:\"Português de Angola\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/pt_AO.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:10:\"pt_PT_ao90\";a:8:{s:8:\"language\";s:10:\"pt_PT_ao90\";s:7:\"version\";s:3:\"5.1\";s:7:\"updated\";s:19:\"2019-02-22 12:37:09\";s:12:\"english_name\";s:27:\"Portuguese (Portugal, AO90)\";s:11:\"native_name\";s:17:\"Português (AO90)\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/translation/core/5.1/pt_PT_ao90.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"rhg\";a:8:{s:8:\"language\";s:3:\"rhg\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-16 13:03:18\";s:12:\"english_name\";s:8:\"Rohingya\";s:11:\"native_name\";s:8:\"Ruáinga\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/rhg.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"rhg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-08-02 10:04:58\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-21 14:39:06\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:3:\"sah\";a:8:{s:8:\"language\";s:3:\"sah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-21 02:06:41\";s:12:\"english_name\";s:5:\"Sakha\";s:11:\"native_name\";s:14:\"Сахалыы\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/sah.zip\";s:3:\"iso\";a:2:{i:2;s:3:\"sah\";i:3;s:3:\"sah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Салҕаа\";}}s:5:\"si_LK\";a:8:{s:8:\"language\";s:5:\"si_LK\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-12 06:00:52\";s:12:\"english_name\";s:7:\"Sinhala\";s:11:\"native_name\";s:15:\"සිංහල\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/si_LK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"si\";i:2;s:3:\"sin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:44:\"දිගටම කරගෙන යන්න\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-08 15:30:32\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:3:\"skr\";a:8:{s:8:\"language\";s:3:\"skr\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-09 14:38:41\";s:12:\"english_name\";s:7:\"Saraiki\";s:11:\"native_name\";s:14:\"سرائیکی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/5.1.1/skr.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"skr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"جاری رکھو\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.9.2\";s:7:\"updated\";s:19:\"2018-01-04 13:33:13\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.2/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-02 15:10:17\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-13 12:26:58\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-04-11 21:25:18\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:3:\"szl\";a:8:{s:8:\"language\";s:3:\"szl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-09-24 19:58:14\";s:12:\"english_name\";s:8:\"Silesian\";s:11:\"native_name\";s:17:\"Ślōnskŏ gŏdka\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/szl.zip\";s:3:\"iso\";a:1:{i:3;s:3:\"szl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:13:\"Kōntynuować\";}}s:5:\"ta_IN\";a:8:{s:8:\"language\";s:5:\"ta_IN\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-27 03:22:47\";s:12:\"english_name\";s:5:\"Tamil\";s:11:\"native_name\";s:15:\"தமிழ்\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/ta_IN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ta\";i:2;s:3:\"tam\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:24:\"தொடரவும்\";}}s:2:\"te\";a:8:{s:8:\"language\";s:2:\"te\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2017-01-26 15:47:39\";s:12:\"english_name\";s:6:\"Telugu\";s:11:\"native_name\";s:18:\"తెలుగు\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/te.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"te\";i:2;s:3:\"tel\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:30:\"కొనసాగించు\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-27 04:33:46\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:2:\"tl\";a:8:{s:8:\"language\";s:2:\"tl\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-12-30 02:38:08\";s:12:\"english_name\";s:7:\"Tagalog\";s:11:\"native_name\";s:7:\"Tagalog\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.7.2/tl.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tl\";i:2;s:3:\"tgl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Magpatuloy\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-03 11:27:41\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"tt_RU\";a:8:{s:8:\"language\";s:5:\"tt_RU\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-11-20 20:20:50\";s:12:\"english_name\";s:5:\"Tatar\";s:11:\"native_name\";s:19:\"Татар теле\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.7.2/tt_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tt\";i:2;s:3:\"tat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:17:\"дәвам итү\";}}s:3:\"tah\";a:8:{s:8:\"language\";s:3:\"tah\";s:7:\"version\";s:5:\"4.7.2\";s:7:\"updated\";s:19:\"2016-03-06 18:39:39\";s:12:\"english_name\";s:8:\"Tahitian\";s:11:\"native_name\";s:10:\"Reo Tahiti\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.7.2/tah.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"ty\";i:2;s:3:\"tah\";i:3;s:3:\"tah\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.9.5\";s:7:\"updated\";s:19:\"2018-04-12 12:31:53\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:16:\"ئۇيغۇرچە\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.9.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-08-27 22:13:08\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:2:\"ur\";a:8:{s:8:\"language\";s:2:\"ur\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-03-31 10:39:40\";s:12:\"english_name\";s:4:\"Urdu\";s:11:\"native_name\";s:8:\"اردو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/ur.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ur\";i:2;s:3:\"urd\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:19:\"جاری رکھیں\";}}s:5:\"uz_UZ\";a:8:{s:8:\"language\";s:5:\"uz_UZ\";s:7:\"version\";s:5:\"5.0.3\";s:7:\"updated\";s:19:\"2019-01-23 12:32:40\";s:12:\"english_name\";s:5:\"Uzbek\";s:11:\"native_name\";s:11:\"O‘zbekcha\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.0.3/uz_UZ.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uz\";i:2;s:3:\"uzb\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:2:\"vi\";a:8:{s:8:\"language\";s:2:\"vi\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-08-24 12:06:15\";s:12:\"english_name\";s:10:\"Vietnamese\";s:11:\"native_name\";s:14:\"Tiếng Việt\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/5.1.1/vi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"vi\";i:2;s:3:\"vie\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Tiếp tục\";}}s:5:\"zh_HK\";a:8:{s:8:\"language\";s:5:\"zh_HK\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-05-09 17:10:44\";s:12:\"english_name\";s:19:\"Chinese (Hong Kong)\";s:11:\"native_name\";s:16:\"香港中文版	\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/zh_HK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-06-27 13:28:37\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"5.1.1\";s:7:\"updated\";s:19:\"2019-07-29 00:19:11\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/5.1.1/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}}', 'no');

-- --------------------------------------------------------

--
-- Structure de la table `wp_postmeta`
--

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `post_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_postmeta`
--

INSERT INTO `wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(4, 5, '_edit_lock', '1583090216:1'),
(5, 6, '_edit_lock', '1583143496:1'),
(6, 6, '_wp_page_template', 'template-institucional.php'),
(7, 8, '_edit_lock', '1583433477:1'),
(8, 8, '_wp_page_template', 'template-become-member.php'),
(9, 10, '_edit_lock', '1583433546:1'),
(10, 10, '_wp_page_template', 'template-ceo-words.php'),
(11, 12, '_edit_lock', '1583433575:1'),
(12, 12, '_wp_page_template', 'template-contact.php'),
(13, 16, '_edit_lock', '1583090959:1'),
(14, 17, '_edit_lock', '1583092528:1'),
(15, 17, '_wp_page_template', 'template-statusAbeti.php'),
(16, 19, '_edit_lock', '1583433485:1'),
(17, 19, '_wp_page_template', 'template-articles.php'),
(18, 21, '_edit_lock', '1583091410:1'),
(37, 25, '_edit_lock', '1583442210:1'),
(47, 28, '_menu_item_type', 'post_type'),
(48, 28, '_menu_item_menu_item_parent', '0'),
(49, 28, '_menu_item_object_id', '19'),
(50, 28, '_menu_item_object', 'page'),
(51, 28, '_menu_item_target', ''),
(52, 28, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(53, 28, '_menu_item_xfn', ''),
(54, 28, '_menu_item_url', ''),
(56, 29, '_menu_item_type', 'post_type'),
(57, 29, '_menu_item_menu_item_parent', '0'),
(58, 29, '_menu_item_object_id', '8'),
(59, 29, '_menu_item_object', 'page'),
(60, 29, '_menu_item_target', ''),
(61, 29, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(62, 29, '_menu_item_xfn', ''),
(63, 29, '_menu_item_url', ''),
(65, 32, '_edit_lock', '1583411996:1'),
(93, 41, '_menu_item_type', 'post_type'),
(94, 41, '_menu_item_menu_item_parent', '0'),
(95, 41, '_menu_item_object_id', '38'),
(96, 41, '_menu_item_object', 'language_switcher'),
(97, 41, '_menu_item_target', ''),
(98, 41, '_menu_item_classes', 'a:5:{i:0;s:0:\"\";i:1;s:31:\"trp-language-switcher-container\";i:2;s:9:\"width40px\";i:3;s:31:\"trp-language-switcher-container\";i:4;s:31:\"trp-language-switcher-container\";}'),
(99, 41, '_menu_item_xfn', ''),
(100, 41, '_menu_item_url', ''),
(102, 42, '_menu_item_type', 'post_type'),
(103, 42, '_menu_item_menu_item_parent', '0'),
(104, 42, '_menu_item_object_id', '39'),
(105, 42, '_menu_item_object', 'language_switcher'),
(106, 42, '_menu_item_target', ''),
(107, 42, '_menu_item_classes', 'a:4:{i:0;s:0:\"\";i:1;s:31:\"trp-language-switcher-container\";i:2;s:31:\"trp-language-switcher-container\";i:3;s:31:\"trp-language-switcher-container\";}'),
(108, 42, '_menu_item_xfn', ''),
(109, 42, '_menu_item_url', ''),
(111, 43, '_menu_item_type', 'post_type'),
(112, 43, '_menu_item_menu_item_parent', '0'),
(113, 43, '_menu_item_object_id', '12'),
(114, 43, '_menu_item_object', 'page'),
(115, 43, '_menu_item_target', ''),
(116, 43, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(117, 43, '_menu_item_xfn', ''),
(118, 43, '_menu_item_url', ''),
(120, 44, '_menu_item_type', 'post_type'),
(121, 44, '_menu_item_menu_item_parent', '0'),
(122, 44, '_menu_item_object_id', '6'),
(123, 44, '_menu_item_object', 'page'),
(124, 44, '_menu_item_target', ''),
(125, 44, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(126, 44, '_menu_item_xfn', ''),
(127, 44, '_menu_item_url', ''),
(129, 45, '_menu_item_type', 'post_type'),
(130, 45, '_menu_item_menu_item_parent', '0'),
(131, 45, '_menu_item_object_id', '17'),
(132, 45, '_menu_item_object', 'page'),
(133, 45, '_menu_item_target', ''),
(134, 45, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(135, 45, '_menu_item_xfn', ''),
(136, 45, '_menu_item_url', ''),
(138, 46, '_menu_item_type', 'post_type'),
(139, 46, '_menu_item_menu_item_parent', '0'),
(140, 46, '_menu_item_object_id', '10'),
(141, 46, '_menu_item_object', 'page'),
(142, 46, '_menu_item_target', ''),
(143, 46, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(144, 46, '_menu_item_xfn', ''),
(145, 46, '_menu_item_url', ''),
(147, 47, '_wp_attached_file', '2020/03/d.1-scaled.jpg'),
(148, 47, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1440;s:4:\"file\";s:22:\"2020/03/d.1-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"d.1-300x169.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:169;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"d.1-1024x576.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"d.1-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"d.1-768x432.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:432;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:16:\"d.1-1536x864.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:864;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:17:\"d.1-2048x1152.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:7:\"d.1.jpg\";}'),
(149, 48, '_edit_lock', '1583109126:1'),
(150, 49, '_wp_attached_file', '2020/03/d.2-scaled.jpg'),
(151, 49, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1744;s:4:\"file\";s:22:\"2020/03/d.2-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"d.2-300x204.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:204;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"d.2-1024x697.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:697;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"d.2-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"d.2-768x523.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:523;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:17:\"d.2-1536x1046.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1046;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:17:\"d.2-2048x1395.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1395;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:7:\"d.2.jpg\";}'),
(152, 50, '_wp_attached_file', '2020/03/d.3-scaled.jpg'),
(153, 50, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1707;s:4:\"file\";s:22:\"2020/03/d.3-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:15:\"d.3-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:16:\"d.3-1024x683.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:683;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"d.3-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:15:\"d.3-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:17:\"d.3-1536x1024.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:17:\"d.3-2048x1366.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1366;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:7:\"d.3.jpg\";}'),
(154, 48, '_customize_restore_dismissed', '1'),
(155, 52, '_edit_lock', '1583109924:1'),
(156, 53, '_edit_lock', '1583433511:1'),
(157, 53, '_wp_page_template', 'template-news.php'),
(158, 1, '_edit_lock', '1583329064:1'),
(161, 1, '_thumbnail_id', '50'),
(162, 58, '_edit_lock', '1583329072:1'),
(164, 58, '_thumbnail_id', '49'),
(165, 60, '_edit_lock', '1583329438:1'),
(167, 62, '_edit_lock', '1583111693:1'),
(169, 62, '_thumbnail_id', '50'),
(170, 64, '_edit_lock', '1583111710:1'),
(172, 64, '_thumbnail_id', '47'),
(173, 66, '_edit_lock', '1583147685:1'),
(175, 66, '_thumbnail_id', '49'),
(176, 68, '_edit_lock', '1583111748:1'),
(178, 60, '_thumbnail_id', '47'),
(179, 69, '_edit_lock', '1583111771:1'),
(181, 71, '_edit_lock', '1583433566:1'),
(182, 71, '_wp_page_template', 'template-congress.php'),
(183, 73, '_edit_lock', '1583443144:1'),
(185, 73, '_thumbnail_id', '50'),
(186, 25, '_wp_page_template', 'template-events.php'),
(188, 77, '_edit_lock', '1583330791:1'),
(191, 19, '_thumbnail_id', '49'),
(193, 77, '_thumbnail_id', '49'),
(194, 80, '_edit_lock', '1583119088:1'),
(197, 80, '_thumbnail_id', '47'),
(199, 52, '_customize_restore_dismissed', '1'),
(200, 86, '_edit_lock', '1583143770:1'),
(201, 86, '_customize_restore_dismissed', '1'),
(204, 90, '_edit_lock', '1583328996:1'),
(207, 93, '_wp_attached_file', '2020/03/sara-bakhshi-MfnX4XtGnvU-unsplash-scaled.jpg'),
(208, 93, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1704;s:4:\"file\";s:52:\"2020/03/sara-bakhshi-MfnX4XtGnvU-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:45:\"sara-bakhshi-MfnX4XtGnvU-unsplash-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:46:\"sara-bakhshi-MfnX4XtGnvU-unsplash-1024x681.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:681;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:45:\"sara-bakhshi-MfnX4XtGnvU-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:45:\"sara-bakhshi-MfnX4XtGnvU-unsplash-768x511.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:511;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:47:\"sara-bakhshi-MfnX4XtGnvU-unsplash-1536x1022.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1022;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:47:\"sara-bakhshi-MfnX4XtGnvU-unsplash-2048x1363.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1363;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:37:\"sara-bakhshi-MfnX4XtGnvU-unsplash.jpg\";}'),
(210, 90, '_thumbnail_id', '93'),
(218, 101, '_edit_lock', '1583329441:1'),
(219, 102, '_edit_lock', '1583329610:1'),
(221, 104, '_wp_attached_file', '2020/03/jc-gellidon-uhXlRnt9dTw-unsplash-scaled.jpg'),
(222, 104, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:1707;s:6:\"height\";i:2560;s:4:\"file\";s:51:\"2020/03/jc-gellidon-uhXlRnt9dTw-unsplash-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:44:\"jc-gellidon-uhXlRnt9dTw-unsplash-200x300.jpg\";s:5:\"width\";i:200;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:45:\"jc-gellidon-uhXlRnt9dTw-unsplash-683x1024.jpg\";s:5:\"width\";i:683;s:6:\"height\";i:1024;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:44:\"jc-gellidon-uhXlRnt9dTw-unsplash-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:45:\"jc-gellidon-uhXlRnt9dTw-unsplash-768x1152.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:1152;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:46:\"jc-gellidon-uhXlRnt9dTw-unsplash-1024x1536.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:1536;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:46:\"jc-gellidon-uhXlRnt9dTw-unsplash-1365x2048.jpg\";s:5:\"width\";i:1365;s:6:\"height\";i:2048;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:36:\"jc-gellidon-uhXlRnt9dTw-unsplash.jpg\";}'),
(224, 102, '_thumbnail_id', '104'),
(225, 105, '_edit_lock', '1583329608:1'),
(227, 105, '_thumbnail_id', '104'),
(231, 110, '_edit_lock', '1583433605:1'),
(232, 112, '_edit_lock', '1583442503:1'),
(234, 114, '_edit_lock', '1583433556:1'),
(235, 116, '_menu_item_type', 'post_type'),
(236, 116, '_menu_item_menu_item_parent', '0'),
(237, 116, '_menu_item_object_id', '6'),
(238, 116, '_menu_item_object', 'page'),
(239, 116, '_menu_item_target', ''),
(240, 116, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(241, 116, '_menu_item_xfn', ''),
(242, 116, '_menu_item_url', ''),
(244, 117, '_menu_item_type', 'post_type'),
(245, 117, '_menu_item_menu_item_parent', '0'),
(246, 117, '_menu_item_object_id', '110'),
(247, 117, '_menu_item_object', 'page'),
(248, 117, '_menu_item_target', ''),
(249, 117, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(250, 117, '_menu_item_xfn', ''),
(251, 117, '_menu_item_url', ''),
(253, 118, '_menu_item_type', 'post_type'),
(254, 118, '_menu_item_menu_item_parent', '0'),
(255, 118, '_menu_item_object_id', '12'),
(256, 118, '_menu_item_object', 'page'),
(257, 118, '_menu_item_target', ''),
(258, 118, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(259, 118, '_menu_item_xfn', ''),
(260, 118, '_menu_item_url', ''),
(262, 119, '_menu_item_type', 'post_type'),
(263, 119, '_menu_item_menu_item_parent', '0'),
(264, 119, '_menu_item_object_id', '112'),
(265, 119, '_menu_item_object', 'post'),
(266, 119, '_menu_item_target', ''),
(267, 119, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(268, 119, '_menu_item_xfn', ''),
(269, 119, '_menu_item_url', ''),
(271, 120, '_menu_item_type', 'post_type'),
(272, 120, '_menu_item_menu_item_parent', '0'),
(273, 120, '_menu_item_object_id', '71'),
(274, 120, '_menu_item_object', 'page'),
(275, 120, '_menu_item_target', ''),
(276, 120, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(277, 120, '_menu_item_xfn', ''),
(278, 120, '_menu_item_url', ''),
(280, 121, '_menu_item_type', 'post_type'),
(281, 121, '_menu_item_menu_item_parent', '0'),
(282, 121, '_menu_item_object_id', '114'),
(283, 121, '_menu_item_object', 'page'),
(284, 121, '_menu_item_target', ''),
(285, 121, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(286, 121, '_menu_item_xfn', ''),
(287, 121, '_menu_item_url', ''),
(289, 114, '_wp_page_template', 'template-certificates.php'),
(290, 122, '_edit_lock', '1583411939:1'),
(291, 123, '_wp_attached_file', '2020/03/luis-carlos-pinto-scaled.jpg'),
(292, 123, '_wp_attachment_metadata', 'a:6:{s:5:\"width\";i:2560;s:6:\"height\";i:1810;s:4:\"file\";s:36:\"2020/03/luis-carlos-pinto-scaled.jpg\";s:5:\"sizes\";a:6:{s:6:\"medium\";a:4:{s:4:\"file\";s:29:\"luis-carlos-pinto-300x212.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:212;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:30:\"luis-carlos-pinto-1024x724.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:724;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"thumbnail\";a:4:{s:4:\"file\";s:29:\"luis-carlos-pinto-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:29:\"luis-carlos-pinto-768x543.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:543;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"1536x1536\";a:4:{s:4:\"file\";s:31:\"luis-carlos-pinto-1536x1086.jpg\";s:5:\"width\";i:1536;s:6:\"height\";i:1086;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:9:\"2048x2048\";a:4:{s:4:\"file\";s:31:\"luis-carlos-pinto-2048x1448.jpg\";s:5:\"width\";i:2048;s:6:\"height\";i:1448;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:6:\"Thiago\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1541487236\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}s:14:\"original_image\";s:21:\"luis-carlos-pinto.jpg\";}'),
(294, 122, '_thumbnail_id', '123'),
(315, 129, '_menu_item_type', 'custom'),
(316, 129, '_menu_item_menu_item_parent', '0'),
(317, 129, '_menu_item_object_id', '129'),
(318, 129, '_menu_item_object', 'custom'),
(319, 129, '_menu_item_target', ''),
(320, 129, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(321, 129, '_menu_item_xfn', ''),
(322, 129, '_menu_item_url', ''),
(324, 131, '_form', '<div class=\"uk-column-1-2@s\">\n<div class=\"contact-form__fields\">\n[text* user-fullname class:uk-input placeholder \"Nome Completo\"]\n[tel user-phone class:uk-input placeholder \"Telefone\"]\n</div>\n</div>\n<div class=\"uk-column-1-2@s\">\n<div class=\"contact-form__fields\">\n[text user-subject class:uk-input placeholder \"Assunto\"]\n[email* user-email class:uk-input placeholder \"Email\"]\n</div>\n</div>\n[textarea user-message class:uk-textarea placeholder \"Mensagem\"]\n[submit class:normal-button class:special-button \"Enviar\"]'),
(325, 131, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:23:\"Brasos \"[user-subject]\"\";s:6:\"sender\";s:31:\"Brasos <helio-cruz@hotmail.com>\";s:9:\"recipient\";s:22:\"helio-cruz@hotmail.com\";s:4:\"body\";s:119:\"De: [user-fullname] <[user-email]>\nAssunto: [user-subject]\n\nMensagem:\n[user-message]\n\nTelefone de contato:\n[user-phone]\";s:18:\"additional_headers\";s:22:\"Reply-To: [user-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}'),
(326, 131, '_mail_2', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:28:\"Brasos \"Aviso de recepção\"\";s:6:\"sender\";s:31:\"Brasos <helio-cruz@hotmail.com>\";s:9:\"recipient\";s:12:\"[user-email]\";s:4:\"body\";s:101:\"Querido(a) [user-fullname],\n\nRecebemos sua mensagem :\n[user-message]\n\nRetornaremos em breve,\n\nBrasos.\";s:18:\"additional_headers\";s:32:\"Reply-To: helio-cruz@hotmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}'),
(327, 131, '_messages', 'a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(328, 131, '_additional_settings', ''),
(329, 131, '_locale', 'pt_BR'),
(332, 132, '_form', '[text* user-fullname class:uk-input class:uk-input-full placeholder \"Nome Completo\"]\n<div class=\"uk-column-1-2@s\">\n<div class=\"contact-form__fields\">\n[email* user-email class:uk-input placeholder \"Email\"]\n[tel* user-phone class:uk-input placeholder \"Telefone\"]\n</div>\n</div>\n[textarea user-message class:uk-textarea placeholder \"Mensagem\"]\n[submit class:normal-button class:special-button \"Enviar\"]'),
(333, 132, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:24:\"Brasos \"Torne-se membro\"\";s:6:\"sender\";s:31:\"Brasos <helio-cruz@hotmail.com>\";s:9:\"recipient\";s:22:\"helio-cruz@hotmail.com\";s:4:\"body\";s:95:\"De: [user-fullname] <[user-email]>\n\nMensagem:\n[user-message]\n\nTelefone de contato:\n[user-phone]\";s:18:\"additional_headers\";s:22:\"Reply-To: [user-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}'),
(334, 132, '_mail_2', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:28:\"Brasos \"Aviso de recepção\"\";s:6:\"sender\";s:31:\"Brasos <helio-cruz@hotmail.com>\";s:9:\"recipient\";s:12:\"[user-email]\";s:4:\"body\";s:110:\"Querido(a) [user-fullname],\n\nObrigado por querer tornar-se membro da Brasos !\n\nRetornaremos em breve,\n\nBrasos.\";s:18:\"additional_headers\";s:32:\"Reply-To: helio-cruz@hotmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:1;s:13:\"exclude_blank\";b:0;}'),
(335, 132, '_messages', 'a:22:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(336, 132, '_additional_settings', ''),
(337, 132, '_locale', 'pt_BR'),
(346, 110, '_wp_page_template', 'template-directory.php'),
(347, 133, '_edit_lock', '1583442284:1'),
(348, 134, '_edit_lock', '1583437610:1'),
(349, 135, '_edit_lock', '1583437632:1'),
(350, 136, '_edit_lock', '1583437732:1'),
(351, 137, '_edit_lock', '1583437787:1'),
(352, 133, '_wp_page_template', 'template-brasos2019-informations.php'),
(353, 139, '_edit_lock', '1583437873:1'),
(354, 139, '_wp_page_template', 'template-brasos2019-inscriptions.php'),
(355, 141, '_edit_lock', '1583437682:1'),
(356, 141, '_wp_page_template', 'template-brasos2019-programation.php'),
(357, 133, '_edit_last', '1'),
(358, 139, '_edit_last', '1'),
(359, 145, '_edit_lock', '1583437760:1'),
(360, 145, '_wp_page_template', 'template-brasos2019-guests.php'),
(361, 147, '_edit_lock', '1583438916:1'),
(362, 147, '_wp_page_template', 'template-brasos2019-certificates.php'),
(363, 149, '_menu_item_type', 'post_type'),
(364, 149, '_menu_item_menu_item_parent', '0'),
(365, 149, '_menu_item_object_id', '147'),
(366, 149, '_menu_item_object', 'page'),
(367, 149, '_menu_item_target', ''),
(368, 149, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(369, 149, '_menu_item_xfn', ''),
(370, 149, '_menu_item_url', ''),
(372, 150, '_menu_item_type', 'post_type'),
(373, 150, '_menu_item_menu_item_parent', '0'),
(374, 150, '_menu_item_object_id', '145'),
(375, 150, '_menu_item_object', 'page'),
(376, 150, '_menu_item_target', ''),
(377, 150, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(378, 150, '_menu_item_xfn', ''),
(379, 150, '_menu_item_url', ''),
(381, 151, '_menu_item_type', 'post_type'),
(382, 151, '_menu_item_menu_item_parent', '0'),
(383, 151, '_menu_item_object_id', '141'),
(384, 151, '_menu_item_object', 'page'),
(385, 151, '_menu_item_target', ''),
(386, 151, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(387, 151, '_menu_item_xfn', ''),
(388, 151, '_menu_item_url', ''),
(390, 152, '_menu_item_type', 'post_type'),
(391, 152, '_menu_item_menu_item_parent', '0'),
(392, 152, '_menu_item_object_id', '139'),
(393, 152, '_menu_item_object', 'page'),
(394, 152, '_menu_item_target', ''),
(395, 152, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(396, 152, '_menu_item_xfn', ''),
(397, 152, '_menu_item_url', ''),
(399, 153, '_menu_item_type', 'post_type'),
(400, 153, '_menu_item_menu_item_parent', '0'),
(401, 153, '_menu_item_object_id', '133'),
(402, 153, '_menu_item_object', 'page'),
(403, 153, '_menu_item_target', ''),
(404, 153, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(405, 153, '_menu_item_xfn', ''),
(406, 153, '_menu_item_url', ''),
(408, 154, '_menu_item_type', 'post_type'),
(409, 154, '_menu_item_menu_item_parent', '0'),
(410, 154, '_menu_item_object_id', '110'),
(411, 154, '_menu_item_object', 'page'),
(412, 154, '_menu_item_target', ''),
(413, 154, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(414, 154, '_menu_item_xfn', ''),
(415, 154, '_menu_item_url', ''),
(417, 73, '_edit_last', '1'),
(419, 73, '_wp_old_slug', 'evento-1'),
(421, 73, '_wp_old_slug', 'brasos2019'),
(422, 112, '_edit_last', '1'),
(424, 157, '_edit_lock', '1583442504:1'),
(426, 159, '_menu_item_type', 'post_type'),
(427, 159, '_menu_item_menu_item_parent', '0'),
(428, 159, '_menu_item_object_id', '157'),
(429, 159, '_menu_item_object', 'post'),
(430, 159, '_menu_item_target', ''),
(431, 159, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(432, 159, '_menu_item_xfn', ''),
(433, 159, '_menu_item_url', ''),
(435, 160, '_menu_item_type', 'post_type'),
(436, 160, '_menu_item_menu_item_parent', '0'),
(437, 160, '_menu_item_object_id', '112'),
(438, 160, '_menu_item_object', 'post'),
(439, 160, '_menu_item_target', ''),
(440, 160, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(441, 160, '_menu_item_xfn', ''),
(442, 160, '_menu_item_url', ''),
(444, 161, '_menu_item_type', 'post_type'),
(445, 161, '_menu_item_menu_item_parent', '0'),
(446, 161, '_menu_item_object_id', '73'),
(447, 161, '_menu_item_object', 'post'),
(448, 161, '_menu_item_target', ''),
(449, 161, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(450, 161, '_menu_item_xfn', ''),
(451, 161, '_menu_item_url', ''),
(455, 112, '_thumbnail_id', '93'),
(457, 157, '_thumbnail_id', '49'),
(458, 189, '_menu_item_type', 'post_type'),
(459, 189, '_menu_item_menu_item_parent', '0'),
(460, 189, '_menu_item_object_id', '133'),
(461, 189, '_menu_item_object', 'page'),
(462, 189, '_menu_item_target', ''),
(463, 189, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(464, 189, '_menu_item_xfn', ''),
(465, 189, '_menu_item_url', '');

-- --------------------------------------------------------

--
-- Structure de la table `wp_posts`
--

CREATE TABLE `wp_posts` (
  `ID` bigint UNSIGNED NOT NULL,
  `post_author` bigint UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_posts`
--

INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2020-02-07 15:10:19', '2020-02-07 18:10:19', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 1', '', 'publish', 'open', 'open', '', 'ola-mundo', '', '', '2020-03-04 10:39:11', '2020-03-04 13:39:11', '', 0, 'http://localhost/Wordpress/Brasos/wp/?p=1', 0, 'post', '', 1),
(5, 1, '2020-03-01 16:19:03', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-03-01 16:19:03', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=5', 0, 'post', '', 0),
(6, 1, '2020-03-01 16:19:30', '2020-03-01 19:19:30', '', 'A Brasos', '', 'publish', 'closed', 'closed', '', 'institucional', '', '', '2020-03-02 05:59:41', '2020-03-02 08:59:41', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=6', 0, 'page', '', 0),
(7, 1, '2020-03-01 16:19:30', '2020-03-01 19:19:30', '', 'Institucional', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2020-03-01 16:19:30', '2020-03-01 19:19:30', '', 6, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2020-03-01 16:24:38', '2020-03-01 19:24:38', '', 'Torne-se Membro', '', 'publish', 'closed', 'closed', '', 'torne-se-membro', '', '', '2020-03-01 16:24:38', '2020-03-01 19:24:38', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=8', 0, 'page', '', 0),
(9, 1, '2020-03-01 16:24:38', '2020-03-01 19:24:38', '', 'Torne-se Membro', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2020-03-01 16:24:38', '2020-03-01 19:24:38', '', 8, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2020-03-01 16:27:30', '2020-03-01 19:27:30', '', 'Palavras do Presidente', '', 'publish', 'closed', 'closed', '', 'palavras-do-presidente', '', '', '2020-03-01 16:27:30', '2020-03-01 19:27:30', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=10', 0, 'page', '', 0),
(11, 1, '2020-03-01 16:27:30', '2020-03-01 19:27:30', '', 'Palavras do Presidente', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2020-03-01 16:27:30', '2020-03-01 19:27:30', '', 10, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2020-03-01 16:29:14', '2020-03-01 19:29:14', '', 'Contato', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2020-03-01 16:29:48', '2020-03-01 19:29:48', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=12', 0, 'page', '', 0),
(13, 1, '2020-03-01 16:29:14', '2020-03-01 19:29:14', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2020-03-01 16:29:14', '2020-03-01 19:29:14', '', 12, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2020-03-01 16:29:48', '2020-03-01 19:29:48', '', 'Contato', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2020-03-01 16:29:48', '2020-03-01 19:29:48', '', 12, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/12-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2020-03-01 16:29:50', '2020-03-01 19:29:50', '', 'Contato', '', 'inherit', 'closed', 'closed', '', '12-autosave-v1', '', '', '2020-03-01 16:29:50', '2020-03-01 19:29:50', '', 12, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/12-autosave-v1/', 0, 'revision', '', 0),
(16, 1, '2020-03-01 16:31:41', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-03-01 16:31:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=16', 0, 'post', '', 0),
(17, 1, '2020-03-01 16:32:11', '2020-03-01 19:32:11', '', 'Estatuo Abeti', '', 'publish', 'closed', 'closed', '', 'estatuo-abeti', '', '', '2020-03-01 16:32:11', '2020-03-01 19:32:11', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=17', 0, 'page', '', 0),
(18, 1, '2020-03-01 16:32:11', '2020-03-01 19:32:11', '', 'Estatuo Abeti', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2020-03-01 16:32:11', '2020-03-01 19:32:11', '', 17, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/17-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2020-03-01 16:36:11', '2020-03-01 19:36:11', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Artigos', '', 'publish', 'closed', 'closed', '', 'artigos', '', '', '2020-03-01 22:34:32', '2020-03-02 01:34:32', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=19', 0, 'page', '', 0),
(20, 1, '2020-03-01 16:36:11', '2020-03-01 19:36:11', '', 'Artigos', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2020-03-01 16:36:11', '2020-03-01 19:36:11', '', 19, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2020-03-01 16:39:13', '2020-03-01 19:39:13', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2020-03-01 16:39:13', '2020-03-01 19:39:13', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=21', 0, 'page', '', 0),
(22, 1, '2020-03-01 16:39:13', '2020-03-01 19:39:13', '', 'Home', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2020-03-01 16:39:13', '2020-03-01 19:39:13', '', 21, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/21-revision-v1/', 0, 'revision', '', 0),
(25, 1, '2020-03-01 16:39:45', '2020-03-01 19:39:45', '', 'Eventos', '', 'publish', 'closed', 'closed', '', 'eventos', '', '', '2020-03-05 17:59:04', '2020-03-05 20:59:04', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=25', 0, 'page', '', 0),
(26, 1, '2020-03-01 16:39:45', '2020-03-01 19:39:45', '', 'Eventos', '', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2020-03-01 16:39:45', '2020-03-01 19:39:45', '', 25, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/25-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2020-03-01 16:39:59', '2020-03-01 19:39:59', ' ', '', '', 'publish', 'closed', 'closed', '', '28', '', '', '2020-03-02 06:14:27', '2020-03-02 09:14:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=28', 1, 'nav_menu_item', '', 0),
(29, 1, '2020-03-01 16:39:59', '2020-03-01 19:39:59', ' ', '', '', 'publish', 'closed', 'closed', '', '29', '', '', '2020-03-02 06:14:27', '2020-03-02 09:14:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=29', 3, 'nav_menu_item', '', 0),
(31, 1, '2020-03-01 16:41:56', '2020-03-01 19:41:56', '', 'Brasos', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2020-03-01 16:41:56', '2020-03-01 19:41:56', '', 6, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/6-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2020-03-01 16:42:24', '2020-03-01 19:42:24', '', 'Institucional', '', 'publish', 'closed', 'closed', '', 'institucional-2', '', '', '2020-03-01 16:42:24', '2020-03-01 19:42:24', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=32', 0, 'page', '', 0),
(33, 1, '2020-03-01 16:42:24', '2020-03-01 19:42:24', '', 'Institucional', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2020-03-01 16:42:24', '2020-03-01 19:42:24', '', 32, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/32-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2020-03-01 16:47:13', '2020-03-01 19:47:13', '', 'Estatuo Abeti', '', 'inherit', 'closed', 'closed', '', '17-autosave-v1', '', '', '2020-03-01 16:47:13', '2020-03-01 19:47:13', '', 17, 'http://localhost/Agencia-Fazer/Brasos/index.php/2020/03/01/17-autosave-v1/', 0, 'revision', '', 0),
(38, 1, '2020-03-01 16:49:03', '2020-03-01 19:49:03', 'pt_BR', 'Portuguese', '', 'publish', 'closed', 'closed', '', 'portuguese', '', '', '2020-03-02 00:35:28', '2020-03-02 03:35:28', '', 0, 'http://localhost/Agencia-Fazer/Brasos/index.php/language_switcher/portuguese/', 0, 'language_switcher', '', 0),
(39, 1, '2020-03-01 16:49:03', '2020-03-01 19:49:03', 'en_US', 'English', '', 'publish', 'closed', 'closed', '', 'english', '', '', '2020-03-02 00:35:28', '2020-03-02 03:35:28', '', 0, 'http://localhost/Agencia-Fazer/Brasos/index.php/language_switcher/english/', 0, 'language_switcher', '', 0),
(40, 1, '2020-03-01 16:49:03', '2020-03-01 19:49:03', 'current_language', 'Idioma atual', '', 'publish', 'closed', 'closed', '', 'idioma-atual', '', '', '2020-03-02 00:35:28', '2020-03-02 03:35:28', '', 0, 'http://localhost/Agencia-Fazer/Brasos/index.php/language_switcher/idioma-atual/', 0, 'language_switcher', '', 0),
(41, 1, '2020-03-01 16:49:38', '2020-03-01 19:49:38', ' ', '', '', 'publish', 'closed', 'closed', '', '41', '', '', '2020-03-01 17:38:47', '2020-03-01 20:38:47', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=41', 1, 'nav_menu_item', '', 0),
(42, 1, '2020-03-01 16:49:38', '2020-03-01 19:49:38', ' ', '', '', 'publish', 'closed', 'closed', '', '42', '', '', '2020-03-01 17:38:47', '2020-03-01 20:38:47', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=42', 2, 'nav_menu_item', '', 0),
(43, 1, '2020-03-01 18:28:29', '2020-03-01 21:28:29', ' ', '', '', 'publish', 'closed', 'closed', '', '43', '', '', '2020-03-02 06:14:27', '2020-03-02 09:14:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=43', 2, 'nav_menu_item', '', 0),
(44, 1, '2020-03-01 18:50:55', '2020-03-01 21:50:55', ' ', '', '', 'publish', 'closed', 'closed', '', '44', '', '', '2020-03-05 16:58:02', '2020-03-05 19:58:02', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=44', 1, 'nav_menu_item', '', 0),
(45, 1, '2020-03-01 18:50:55', '2020-03-01 21:50:55', ' ', '', '', 'publish', 'closed', 'closed', '', '45', '', '', '2020-03-05 16:58:02', '2020-03-05 19:58:02', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=45', 2, 'nav_menu_item', '', 0),
(46, 1, '2020-03-01 18:50:56', '2020-03-01 21:50:56', ' ', '', '', 'publish', 'closed', 'closed', '', '46', '', '', '2020-03-05 16:58:02', '2020-03-05 19:58:02', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=46', 3, 'nav_menu_item', '', 0),
(47, 1, '2020-03-01 21:31:30', '2020-03-02 00:31:30', '', 'd.1', '', 'inherit', 'open', 'closed', '', 'd-1', '', '', '2020-03-01 21:31:30', '2020-03-02 00:31:30', '', 0, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.1.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2020-03-01 21:32:06', '0000-00-00 00:00:00', '{\n    \"brasos::brasos_bg_slide_3\": {\n        \"value\": \"http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.1-scaled.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-03-02 00:32:06\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '3cbcdd5c-2504-49c5-aa92-34c726649896', '', '', '2020-03-01 21:32:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=48', 0, 'customize_changeset', '', 0),
(49, 1, '2020-03-01 21:33:00', '2020-03-02 00:33:00', '', 'd.2', '', 'inherit', 'open', 'closed', '', 'd-2', '', '', '2020-03-01 21:33:00', '2020-03-02 00:33:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.2.jpg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2020-03-01 21:33:07', '2020-03-02 00:33:07', '', 'd.3', '', 'inherit', 'open', 'closed', '', 'd-3', '', '', '2020-03-01 21:33:07', '2020-03-02 00:33:07', '', 0, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.3.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2020-03-01 21:45:24', '0000-00-00 00:00:00', '{\n    \"brasos::brasos_bg_slide_1\": {\n        \"value\": \"http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.1-scaled.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-03-02 00:45:24\"\n    },\n    \"brasos::brasos_bg_slide_2\": {\n        \"value\": \"http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.2-scaled.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-03-02 00:45:24\"\n    },\n    \"brasos::brasos_bg_slide_3\": {\n        \"value\": \"http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.3-scaled.jpg\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-03-02 00:45:24\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '1586405f-ca24-4da2-b2af-e0dd10105d7c', '', '', '2020-03-01 21:45:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=52', 0, 'customize_changeset', '', 0),
(53, 1, '2020-03-01 22:12:01', '2020-03-02 01:12:01', '', 'Noticias', '', 'publish', 'closed', 'closed', '', 'noticias', '', '', '2020-03-01 22:12:01', '2020-03-02 01:12:01', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=53', 0, 'page', '', 0),
(54, 1, '2020-03-01 22:12:01', '2020-03-02 01:12:01', '', 'Noticias', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2020-03-01 22:12:01', '2020-03-02 01:12:01', '', 53, 'http://localhost/Agencia-Fazer/Brasos/53-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2020-03-01 22:14:53', '2020-03-02 01:14:53', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 1', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2020-03-01 22:14:53', '2020-03-02 01:14:53', '', 1, 'http://localhost/Agencia-Fazer/Brasos/1-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2020-03-01 22:15:11', '2020-03-02 01:15:11', '', 'Noticias', '', 'inherit', 'closed', 'closed', '', '53-autosave-v1', '', '', '2020-03-01 22:15:11', '2020-03-02 01:15:11', '', 53, 'http://localhost/Agencia-Fazer/Brasos/53-autosave-v1/', 0, 'revision', '', 0),
(58, 1, '2020-03-01 22:16:26', '2020-03-02 01:16:26', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 2', '', 'publish', 'open', 'open', '', 'noticia-2', '', '', '2020-03-04 10:40:16', '2020-03-04 13:40:16', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=58', 0, 'post', '', 0),
(59, 1, '2020-03-01 22:16:26', '2020-03-02 01:16:26', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 2', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2020-03-01 22:16:26', '2020-03-02 01:16:26', '', 58, 'http://localhost/Agencia-Fazer/Brasos/58-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2020-03-01 22:16:59', '2020-03-02 01:16:59', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> </p>\n<!-- /wp:paragraph -->', 'Noticia 3', '', 'publish', 'open', 'open', '', 'noticia-3', '', '', '2020-03-04 10:41:04', '2020-03-04 13:41:04', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=60', 0, 'post', '', 0),
(61, 1, '2020-03-01 22:16:59', '2020-03-02 01:16:59', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 3', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2020-03-01 22:16:59', '2020-03-02 01:16:59', '', 60, 'http://localhost/Agencia-Fazer/Brasos/60-revision-v1/', 0, 'revision', '', 0),
(62, 1, '2020-03-01 22:17:16', '2020-03-02 01:17:16', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 4', '', 'publish', 'open', 'open', '', 'noticia-4', '', '', '2020-03-01 22:17:16', '2020-03-02 01:17:16', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=62', 0, 'post', '', 0),
(63, 1, '2020-03-01 22:17:16', '2020-03-02 01:17:16', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 4', '', 'inherit', 'closed', 'closed', '', '62-revision-v1', '', '', '2020-03-01 22:17:16', '2020-03-02 01:17:16', '', 62, 'http://localhost/Agencia-Fazer/Brasos/62-revision-v1/', 0, 'revision', '', 0),
(64, 1, '2020-03-01 22:17:33', '2020-03-02 01:17:33', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 5', '', 'publish', 'open', 'open', '', 'noticia-5', '', '', '2020-03-01 22:17:33', '2020-03-02 01:17:33', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=64', 0, 'post', '', 0),
(65, 1, '2020-03-01 22:17:33', '2020-03-02 01:17:33', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 5', '', 'inherit', 'closed', 'closed', '', '64-revision-v1', '', '', '2020-03-01 22:17:33', '2020-03-02 01:17:33', '', 64, 'http://localhost/Agencia-Fazer/Brasos/64-revision-v1/', 0, 'revision', '', 0),
(66, 1, '2020-03-01 22:17:46', '2020-03-02 01:17:46', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 6', '', 'publish', 'open', 'open', '', 'noticia-6', '', '', '2020-03-02 08:16:56', '2020-03-02 11:16:56', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=66', 0, 'post', '', 0),
(67, 1, '2020-03-01 22:17:46', '2020-03-02 01:17:46', '', 'Noticia 6', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2020-03-01 22:17:46', '2020-03-02 01:17:46', '', 66, 'http://localhost/Agencia-Fazer/Brasos/66-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2020-03-01 22:18:10', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-03-01 22:18:10', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=68', 0, 'post', '', 0),
(69, 1, '2020-03-01 22:18:34', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-03-01 22:18:34', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=69', 0, 'post', '', 0),
(70, 1, '2020-03-01 22:19:47', '2020-03-02 01:19:47', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 6', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2020-03-01 22:19:47', '2020-03-02 01:19:47', '', 66, 'http://localhost/Agencia-Fazer/Brasos/66-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2020-03-01 22:25:28', '2020-03-02 01:25:28', '', 'Congressos', '', 'publish', 'closed', 'closed', '', 'congressos', '', '', '2020-03-01 22:25:28', '2020-03-02 01:25:28', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=71', 0, 'page', '', 0),
(72, 1, '2020-03-01 22:25:28', '2020-03-02 01:25:28', '', 'Congressos', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2020-03-01 22:25:28', '2020-03-02 01:25:28', '', 71, 'http://localhost/Agencia-Fazer/Brasos/71-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2020-03-01 22:26:00', '2020-03-02 01:26:00', '', 'BRASOStbt 2019', '', 'publish', 'open', 'open', '', 'brasos-2019', '', '', '2020-03-05 18:09:54', '2020-03-05 21:09:54', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=73', 0, 'post', '', 0),
(74, 1, '2020-03-01 22:26:00', '2020-03-02 01:26:00', '', 'Evento 1', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2020-03-01 22:26:00', '2020-03-02 01:26:00', '', 73, 'http://localhost/Agencia-Fazer/Brasos/73-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2020-03-01 22:31:36', '2020-03-02 01:31:36', '<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Evento 1', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2020-03-01 22:31:36', '2020-03-02 01:31:36', '', 73, 'http://localhost/Agencia-Fazer/Brasos/73-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2020-03-01 22:32:31', '2020-03-02 01:32:31', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->', 'Artigo 1', '', 'publish', 'open', 'open', '', 'artigo-1', '', '', '2020-03-04 10:49:22', '2020-03-04 13:49:22', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=77', 0, 'post', '', 0),
(78, 1, '2020-03-01 22:32:31', '2020-03-02 01:32:31', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Artigo 1', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2020-03-01 22:32:31', '2020-03-02 01:32:31', '', 77, 'http://localhost/Agencia-Fazer/Brasos/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2020-03-01 22:34:25', '2020-03-02 01:34:25', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Artigos', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2020-03-01 22:34:25', '2020-03-02 01:34:25', '', 19, 'http://localhost/Agencia-Fazer/Brasos/19-revision-v1/', 0, 'revision', '', 0),
(80, 1, '2020-03-01 22:37:08', '2020-03-02 01:37:08', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Congresso 1', '', 'publish', 'open', 'open', '', 'congresso-1', '', '', '2020-03-01 22:37:31', '2020-03-02 01:37:31', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=80', 0, 'post', '', 0),
(81, 1, '2020-03-01 22:37:08', '2020-03-02 01:37:08', '', 'Congresso 1', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2020-03-01 22:37:08', '2020-03-02 01:37:08', '', 80, 'http://localhost/Agencia-Fazer/Brasos/80-revision-v1/', 0, 'revision', '', 0),
(82, 1, '2020-03-01 22:37:31', '2020-03-02 01:37:31', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Congresso 1', '', 'inherit', 'closed', 'closed', '', '80-revision-v1', '', '', '2020-03-01 22:37:31', '2020-03-02 01:37:31', '', 80, 'http://localhost/Agencia-Fazer/Brasos/80-revision-v1/', 0, 'revision', '', 0),
(83, 1, '2020-03-02 05:59:38', '2020-03-02 08:59:38', '', 'A Brasos', '', 'inherit', 'closed', 'closed', '', '6-autosave-v1', '', '', '2020-03-02 05:59:38', '2020-03-02 08:59:38', '', 6, 'http://localhost/Agencia-Fazer/Brasos/6-autosave-v1/', 0, 'revision', '', 0),
(84, 1, '2020-03-02 05:59:41', '2020-03-02 08:59:41', '', 'A Brasos', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2020-03-02 05:59:41', '2020-03-02 08:59:41', '', 6, 'http://localhost/Agencia-Fazer/Brasos/6-revision-v1/', 0, 'revision', '', 0),
(86, 1, '2020-03-02 07:09:30', '0000-00-00 00:00:00', '{\n    \"brasos::brasos_call_to_content-1\": {\n        \"value\": \"Cursos pr\\u00e9-simp\\u00f3sio de Inje\\u00e7\\u00f5es intra-articulares guiadas por Ultrassonografia em Osteoartrite do Joelho,\\n Quadril, Ombro e Tornozelo.\",\n        \"type\": \"theme_mod\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2020-03-02 10:09:30\"\n    }\n}', '', '', 'auto-draft', 'closed', 'closed', '', '240dc1eb-f09b-4b0e-bda6-d6725a3ef58c', '', '', '2020-03-02 07:09:30', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=86', 0, 'customize_changeset', '', 0),
(89, 1, '2020-03-02 08:16:56', '2020-03-02 11:16:56', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 6', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2020-03-02 08:16:56', '2020-03-02 11:16:56', '', 66, 'http://localhost/Agencia-Fazer/Brasos/66-revision-v1/', 0, 'revision', '', 0),
(90, 1, '2020-03-04 06:26:46', '2020-03-04 09:26:46', '<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Ultima Noticia', '', 'publish', 'open', 'open', '', 'helio', '', '', '2020-03-04 10:38:46', '2020-03-04 13:38:46', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=90', 0, 'post', '', 0),
(91, 1, '2020-03-04 06:26:46', '2020-03-04 09:26:46', '<!-- wp:paragraph -->\n<p>dfgdgdfgdfg</p>\n<!-- /wp:paragraph -->', 'Helio', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2020-03-04 06:26:46', '2020-03-04 09:26:46', '', 90, 'http://localhost/Agencia-Fazer/Brasos/90-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2020-03-04 06:37:51', '2020-03-04 09:37:51', '<!-- wp:paragraph -->\n<p> Lorem hehe</p>\n<!-- /wp:paragraph -->', 'Ultima Noticia', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2020-03-04 06:37:51', '2020-03-04 09:37:51', '', 90, 'http://localhost/Agencia-Fazer/Brasos/90-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2020-03-04 06:39:45', '2020-03-04 09:39:45', '', 'sara-bakhshi-MfnX4XtGnvU-unsplash', '', 'inherit', 'open', 'closed', '', 'sara-bakhshi-mfnx4xtgnvu-unsplash', '', '', '2020-03-04 06:39:45', '2020-03-04 09:39:45', '', 90, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/sara-bakhshi-MfnX4XtGnvU-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(94, 1, '2020-03-04 10:03:12', '2020-03-04 13:03:12', '<!-- wp:paragraph -->\n<p> Lorem heheqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq</p>\n<!-- /wp:paragraph -->', 'Ultima Noticia', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2020-03-04 10:03:12', '2020-03-04 13:03:12', '', 90, 'http://localhost/Agencia-Fazer/Brasos/90-revision-v1/', 0, 'revision', '', 0),
(95, 1, '2020-03-04 10:28:32', '2020-03-04 13:28:32', '<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Ultima Noticia', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2020-03-04 10:28:32', '2020-03-04 13:28:32', '', 90, 'http://localhost/Agencia-Fazer/Brasos/90-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2020-03-04 10:38:46', '2020-03-04 13:38:46', '<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Ultima Noticia', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2020-03-04 10:38:46', '2020-03-04 13:38:46', '', 90, 'http://localhost/Agencia-Fazer/Brasos/90-revision-v1/', 0, 'revision', '', 0),
(97, 1, '2020-03-04 10:39:11', '2020-03-04 13:39:11', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 1', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2020-03-04 10:39:11', '2020-03-04 13:39:11', '', 1, 'http://localhost/Agencia-Fazer/Brasos/1-revision-v1/', 0, 'revision', '', 0),
(98, 1, '2020-03-04 10:40:16', '2020-03-04 13:40:16', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 2', '', 'inherit', 'closed', 'closed', '', '58-revision-v1', '', '', '2020-03-04 10:40:16', '2020-03-04 13:40:16', '', 58, 'http://localhost/Agencia-Fazer/Brasos/58-revision-v1/', 0, 'revision', '', 0),
(99, 1, '2020-03-04 10:40:23', '2020-03-04 13:40:23', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'Noticia 3', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2020-03-04 10:40:23', '2020-03-04 13:40:23', '', 60, 'http://localhost/Agencia-Fazer/Brasos/60-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2020-03-04 10:41:04', '2020-03-04 13:41:04', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> </p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p> </p>\n<!-- /wp:paragraph -->', 'Noticia 3', '', 'inherit', 'closed', 'closed', '', '60-revision-v1', '', '', '2020-03-04 10:41:04', '2020-03-04 13:41:04', '', 60, 'http://localhost/Agencia-Fazer/Brasos/60-revision-v1/', 0, 'revision', '', 0),
(101, 1, '2020-03-04 10:46:24', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2020-03-04 10:46:24', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=101', 0, 'post', '', 0),
(102, 1, '2020-03-04 10:47:08', '2020-03-04 13:47:08', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->', 'Artigo 2', '', 'publish', 'open', 'open', '', 'artigo-2', '', '', '2020-03-04 10:48:29', '2020-03-04 13:48:29', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=102', 0, 'post', '', 0),
(103, 1, '2020-03-04 10:47:08', '2020-03-04 13:47:08', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->', 'Artigo 2', '', 'inherit', 'closed', 'closed', '', '102-revision-v1', '', '', '2020-03-04 10:47:08', '2020-03-04 13:47:08', '', 102, 'http://localhost/Agencia-Fazer/Brasos/102-revision-v1/', 0, 'revision', '', 0),
(104, 1, '2020-03-04 10:48:19', '2020-03-04 13:48:19', '', 'jc-gellidon-uhXlRnt9dTw-unsplash', '', 'inherit', 'open', 'closed', '', 'jc-gellidon-uhxlrnt9dtw-unsplash', '', '', '2020-03-04 10:48:19', '2020-03-04 13:48:19', '', 102, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/jc-gellidon-uhXlRnt9dTw-unsplash.jpg', 0, 'attachment', 'image/jpeg', 0),
(105, 1, '2020-03-04 10:48:51', '2020-03-04 13:48:51', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->', 'Artigo 3', '', 'publish', 'open', 'open', '', 'artigo-3', '', '', '2020-03-04 10:48:51', '2020-03-04 13:48:51', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=105', 0, 'post', '', 0),
(106, 1, '2020-03-04 10:48:51', '2020-03-04 13:48:51', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->', 'Artigo 3', '', 'inherit', 'closed', 'closed', '', '105-revision-v1', '', '', '2020-03-04 10:48:51', '2020-03-04 13:48:51', '', 105, 'http://localhost/Agencia-Fazer/Brasos/105-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2020-03-04 10:49:22', '2020-03-04 13:49:22', '<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a</p>\n<!-- /wp:paragraph -->', 'Artigo 1', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2020-03-04 10:49:22', '2020-03-04 13:49:22', '', 77, 'http://localhost/Agencia-Fazer/Brasos/77-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2020-03-04 11:22:48', '2020-03-04 14:22:48', '', 'Conselho Diretor', '', 'publish', 'closed', 'closed', '', 'conselho-diretor', '', '', '2020-03-05 15:42:20', '2020-03-05 18:42:20', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=110', 0, 'page', '', 0),
(111, 1, '2020-03-04 11:22:48', '2020-03-04 14:22:48', '', 'Conselho Diretor', '', 'inherit', 'closed', 'closed', '', '110-revision-v1', '', '', '2020-03-04 11:22:48', '2020-03-04 14:22:48', '', 110, 'http://localhost/Agencia-Fazer/Brasos/110-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2020-03-04 11:23:49', '2020-03-04 14:23:49', '', 'BRASIT 2020', '', 'publish', 'open', 'open', '', 'brasit-2020', '', '', '2020-03-05 18:10:37', '2020-03-05 21:10:37', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=112', 0, 'post', '', 0),
(113, 1, '2020-03-04 11:23:49', '2020-03-04 14:23:49', '', 'Brasit 2020', '', 'inherit', 'closed', 'closed', '', '112-revision-v1', '', '', '2020-03-04 11:23:49', '2020-03-04 14:23:49', '', 112, 'http://localhost/Agencia-Fazer/Brasos/112-revision-v1/', 0, 'revision', '', 0),
(114, 1, '2020-03-04 11:24:11', '2020-03-04 14:24:11', '', 'Certificados', '', 'publish', 'closed', 'closed', '', 'certificados', '', '', '2020-03-04 17:11:02', '2020-03-04 20:11:02', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=114', 0, 'page', '', 0),
(115, 1, '2020-03-04 11:24:11', '2020-03-04 14:24:11', '', 'Certificados', '', 'inherit', 'closed', 'closed', '', '114-revision-v1', '', '', '2020-03-04 11:24:11', '2020-03-04 14:24:11', '', 114, 'http://localhost/Agencia-Fazer/Brasos/114-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2020-03-04 11:25:27', '2020-03-04 14:25:27', ' ', '', '', 'publish', 'closed', 'closed', '', '116', '', '', '2020-03-04 11:25:27', '2020-03-04 14:25:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=116', 1, 'nav_menu_item', '', 0),
(117, 1, '2020-03-04 11:25:27', '2020-03-04 14:25:27', ' ', '', '', 'publish', 'closed', 'closed', '', '117', '', '', '2020-03-04 11:25:27', '2020-03-04 14:25:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=117', 2, 'nav_menu_item', '', 0),
(118, 1, '2020-03-04 11:25:27', '2020-03-04 14:25:27', ' ', '', '', 'publish', 'closed', 'closed', '', '118', '', '', '2020-03-04 11:25:27', '2020-03-04 14:25:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=118', 3, 'nav_menu_item', '', 0),
(119, 1, '2020-03-04 11:25:27', '2020-03-04 14:25:27', ' ', '', '', 'publish', 'closed', 'closed', '', '119', '', '', '2020-03-04 11:25:27', '2020-03-04 14:25:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=119', 4, 'nav_menu_item', '', 0),
(120, 1, '2020-03-04 11:25:27', '2020-03-04 14:25:27', ' ', '', '', 'publish', 'closed', 'closed', '', '120', '', '', '2020-03-04 11:25:27', '2020-03-04 14:25:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=120', 5, 'nav_menu_item', '', 0),
(121, 1, '2020-03-04 11:25:27', '2020-03-04 14:25:27', ' ', '', '', 'publish', 'closed', 'closed', '', '121', '', '', '2020-03-04 11:25:27', '2020-03-04 14:25:27', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=121', 6, 'nav_menu_item', '', 0),
(122, 1, '2020-03-04 14:00:09', '2020-03-04 17:00:09', '<!-- wp:paragraph -->\n<p>Certificado de Desenvolvimento Web</p>\n<!-- /wp:paragraph -->', '', '', 'publish', 'open', 'open', '', 'helio-cruz', '', '', '2020-03-04 14:07:30', '2020-03-04 17:07:30', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=122', 0, 'post', '', 0),
(123, 1, '2020-03-04 13:59:08', '2020-03-04 16:59:08', '', 'luis-carlos-pinto', '', 'inherit', 'open', 'closed', '', 'luis-carlos-pinto', '', '', '2020-03-04 13:59:08', '2020-03-04 16:59:08', '', 122, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/luis-carlos-pinto.jpg', 0, 'attachment', 'image/jpeg', 0),
(124, 1, '2020-03-04 14:00:09', '2020-03-04 17:00:09', '', 'Helio Cruz', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2020-03-04 14:00:09', '2020-03-04 17:00:09', '', 122, 'http://localhost/Agencia-Fazer/Brasos/122-revision-v1/', 0, 'revision', '', 0),
(125, 1, '2020-03-04 14:06:08', '2020-03-04 17:06:08', '', 'Certificado de Helio Cruz', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2020-03-04 14:06:08', '2020-03-04 17:06:08', '', 122, 'http://localhost/Agencia-Fazer/Brasos/122-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2020-03-04 14:07:30', '2020-03-04 17:07:30', '<!-- wp:paragraph -->\n<p>Certificado de Desenvolvimento Web</p>\n<!-- /wp:paragraph -->', '', '', 'inherit', 'closed', 'closed', '', '122-revision-v1', '', '', '2020-03-04 14:07:30', '2020-03-04 17:07:30', '', 122, 'http://localhost/Agencia-Fazer/Brasos/122-revision-v1/', 0, 'revision', '', 0),
(129, 1, '2020-03-04 14:51:33', '2020-03-04 17:51:33', '', '<a href=\"https://www.linkedin.com/company/brasos/\" uk-icon=\"linkedin\" target=\"_blank\" rel=\"noopener noreferrer\"></a>', '', 'publish', 'closed', 'closed', '', 'item-do-menu', '', '', '2020-03-04 14:53:56', '2020-03-04 17:53:56', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=129', 1, 'nav_menu_item', '', 0),
(131, 1, '2020-03-05 04:25:44', '2020-03-05 07:25:44', '<div class=\"uk-column-1-2@s\">\r\n<div class=\"contact-form__fields\">\r\n[text* user-fullname class:uk-input placeholder \"Nome Completo\"]\r\n[tel user-phone class:uk-input placeholder \"Telefone\"]\r\n</div>\r\n</div>\r\n<div class=\"uk-column-1-2@s\">\r\n<div class=\"contact-form__fields\">\r\n[text user-subject class:uk-input placeholder \"Assunto\"]\r\n[email* user-email class:uk-input placeholder \"Email\"]\r\n</div>\r\n</div>\r\n[textarea user-message class:uk-textarea placeholder \"Mensagem\"]\r\n[submit class:normal-button class:special-button \"Enviar\"]\n1\nBrasos \"[user-subject]\"\nBrasos <helio-cruz@hotmail.com>\nhelio-cruz@hotmail.com\nDe: [user-fullname] <[user-email]>\r\nAssunto: [user-subject]\r\n\r\nMensagem:\r\n[user-message]\r\n\r\nTelefone de contato:\r\n[user-phone]\nReply-To: [user-email]\n\n1\n\n1\nBrasos \"Aviso de recepção\"\nBrasos <helio-cruz@hotmail.com>\n[user-email]\nQuerido(a) [user-fullname],\r\n\r\nRecebemos sua mensagem :\r\n[user-message]\r\n\r\nRetornaremos em breve,\r\n\r\nBrasos.\nReply-To: helio-cruz@hotmail.com\n\n1\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contato', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2020-03-05 07:56:02', '2020-03-05 10:56:02', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?post_type=wpcf7_contact_form&#038;p=131', 0, 'wpcf7_contact_form', '', 0),
(132, 1, '2020-03-05 06:01:44', '2020-03-05 09:01:44', '[text* user-fullname class:uk-input class:uk-input-full placeholder \"Nome Completo\"]\r\n<div class=\"uk-column-1-2@s\">\r\n<div class=\"contact-form__fields\">\r\n[email* user-email class:uk-input placeholder \"Email\"]\r\n[tel* user-phone class:uk-input placeholder \"Telefone\"]\r\n</div>\r\n</div>\r\n[textarea user-message class:uk-textarea placeholder \"Mensagem\"]\r\n[submit class:normal-button class:special-button \"Enviar\"]\n1\nBrasos \"Torne-se membro\"\nBrasos <helio-cruz@hotmail.com>\nhelio-cruz@hotmail.com\nDe: [user-fullname] <[user-email]>\r\n\r\nMensagem:\r\n[user-message]\r\n\r\nTelefone de contato:\r\n[user-phone]\nReply-To: [user-email]\n\n1\n\n1\nBrasos \"Aviso de recepção\"\nBrasos <helio-cruz@hotmail.com>\n[user-email]\nQuerido(a) [user-fullname],\r\n\r\nObrigado por querer tornar-se membro da Brasos !\r\n\r\nRetornaremos em breve,\r\n\r\nBrasos.\nReply-To: helio-cruz@hotmail.com\n\n1\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Membro', '', 'publish', 'closed', 'closed', '', 'contato_copy', '', '', '2020-03-05 08:03:04', '2020-03-05 11:03:04', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?post_type=wpcf7_contact_form&#038;p=132', 0, 'wpcf7_contact_form', '', 0),
(133, 1, '2020-03-05 16:49:03', '2020-03-05 19:49:03', '', 'Brasos2019 - Informações Gerais', '', 'publish', 'closed', 'closed', '', 'brasos2019-informations', '', '', '2020-03-05 18:06:01', '2020-03-05 21:06:01', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=133', 0, 'page', '', 0),
(134, 1, '2020-03-05 16:44:07', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2020-03-05 16:44:07', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=134', 0, 'page', '', 0),
(135, 1, '2020-03-05 16:44:07', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2020-03-05 16:44:07', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=135', 0, 'page', '', 0),
(136, 1, '2020-03-05 16:44:11', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2020-03-05 16:44:11', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=136', 0, 'page', '', 0),
(137, 1, '2020-03-05 16:44:12', '0000-00-00 00:00:00', '', 'Rascunho automático', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2020-03-05 16:44:12', '0000-00-00 00:00:00', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=137', 0, 'page', '', 0),
(138, 1, '2020-03-05 16:49:03', '2020-03-05 19:49:03', '', 'Brasos2019 - Informations', '', 'inherit', 'closed', 'closed', '', '133-revision-v1', '', '', '2020-03-05 16:49:03', '2020-03-05 19:49:03', '', 133, 'http://localhost/Agencia-Fazer/Brasos/133-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2020-03-05 16:49:30', '2020-03-05 19:49:30', '', 'Brasos2019 - Inscrições/Pagamento', '', 'publish', 'closed', 'closed', '', 'brasos2019-inscriptions', '', '', '2020-03-05 16:51:13', '2020-03-05 19:51:13', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=139', 0, 'page', '', 0),
(140, 1, '2020-03-05 16:49:30', '2020-03-05 19:49:30', '', 'Brasos2019 - Inscriptions', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2020-03-05 16:49:30', '2020-03-05 19:49:30', '', 139, 'http://localhost/Agencia-Fazer/Brasos/139-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2020-03-05 16:50:25', '2020-03-05 19:50:25', '', 'Brasos2019 - Programação', '', 'publish', 'closed', 'closed', '', 'brasos2019-programacao', '', '', '2020-03-05 16:50:25', '2020-03-05 19:50:25', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=141', 0, 'page', '', 0),
(142, 1, '2020-03-05 16:50:25', '2020-03-05 19:50:25', '', 'Brasos2019 - Programação', '', 'inherit', 'closed', 'closed', '', '141-revision-v1', '', '', '2020-03-05 16:50:25', '2020-03-05 19:50:25', '', 141, 'http://localhost/Agencia-Fazer/Brasos/141-revision-v1/', 0, 'revision', '', 0),
(143, 1, '2020-03-05 16:50:59', '2020-03-05 19:50:59', '', 'Brasos2019 - Informações Gerais', '', 'inherit', 'closed', 'closed', '', '133-revision-v1', '', '', '2020-03-05 16:50:59', '2020-03-05 19:50:59', '', 133, 'http://localhost/Agencia-Fazer/Brasos/133-revision-v1/', 0, 'revision', '', 0),
(144, 1, '2020-03-05 16:51:13', '2020-03-05 19:51:13', '', 'Brasos2019 - Inscrições/Pagamento', '', 'inherit', 'closed', 'closed', '', '139-revision-v1', '', '', '2020-03-05 16:51:13', '2020-03-05 19:51:13', '', 139, 'http://localhost/Agencia-Fazer/Brasos/139-revision-v1/', 0, 'revision', '', 0),
(145, 1, '2020-03-05 16:51:37', '2020-03-05 19:51:37', '', 'Brasos2019 – Palestrantes convidados', '', 'publish', 'closed', 'closed', '', 'brasos2019-palestrantes-convidados', '', '', '2020-03-05 16:51:37', '2020-03-05 19:51:37', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=145', 0, 'page', '', 0),
(146, 1, '2020-03-05 16:51:37', '2020-03-05 19:51:37', '', 'Brasos2019 – Palestrantes convidados', '', 'inherit', 'closed', 'closed', '', '145-revision-v1', '', '', '2020-03-05 16:51:37', '2020-03-05 19:51:37', '', 145, 'http://localhost/Agencia-Fazer/Brasos/145-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(147, 1, '2020-03-05 16:52:19', '2020-03-05 19:52:19', '', 'Brasos2019 - Certificados', '', 'publish', 'closed', 'closed', '', 'brasos2019-certificados', '', '', '2020-03-05 16:52:19', '2020-03-05 19:52:19', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?page_id=147', 0, 'page', '', 0),
(148, 1, '2020-03-05 16:52:19', '2020-03-05 19:52:19', '', 'Brasos2019 - Certificados', '', 'inherit', 'closed', 'closed', '', '147-revision-v1', '', '', '2020-03-05 16:52:19', '2020-03-05 19:52:19', '', 147, 'http://localhost/Agencia-Fazer/Brasos/147-revision-v1/', 0, 'revision', '', 0),
(149, 1, '2020-03-05 16:52:51', '2020-03-05 19:52:51', '', 'Certificados', '', 'publish', 'closed', 'closed', '', 'brasos2019-certificados', '', '', '2020-03-05 17:11:43', '2020-03-05 20:11:43', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=149', 2, 'nav_menu_item', '', 0),
(150, 1, '2020-03-05 16:52:51', '2020-03-05 19:52:51', '', 'Palestrantes convidados', '', 'publish', 'closed', 'closed', '', '150', '', '', '2020-03-05 17:11:43', '2020-03-05 20:11:43', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=150', 4, 'nav_menu_item', '', 0),
(151, 1, '2020-03-05 16:52:51', '2020-03-05 19:52:51', '', 'Programação', '', 'publish', 'closed', 'closed', '', 'brasos2019-programacao', '', '', '2020-03-05 17:11:43', '2020-03-05 20:11:43', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=151', 3, 'nav_menu_item', '', 0),
(152, 1, '2020-03-05 16:52:51', '2020-03-05 19:52:51', '', 'Inscrições/Pagamento', '', 'publish', 'closed', 'closed', '', 'brasos2019-inscricoes-pagamento', '', '', '2020-03-05 17:11:43', '2020-03-05 20:11:43', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=152', 5, 'nav_menu_item', '', 0),
(153, 1, '2020-03-05 16:52:51', '2020-03-05 19:52:51', '', 'Informações Gerais', '', 'publish', 'closed', 'closed', '', 'brasos2019-informacoes-gerais', '', '', '2020-03-05 17:11:43', '2020-03-05 20:11:43', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=153', 1, 'nav_menu_item', '', 0),
(154, 1, '2020-03-05 16:58:02', '2020-03-05 19:58:02', ' ', '', '', 'publish', 'closed', 'closed', '', '154', '', '', '2020-03-05 16:58:02', '2020-03-05 19:58:02', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=154', 4, 'nav_menu_item', '', 0),
(155, 1, '2020-03-05 17:00:53', '2020-03-05 20:00:53', '<!-- wp:paragraph -->\n<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>\n<!-- /wp:paragraph -->', 'BRASOStbt 2019', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2020-03-05 17:00:53', '2020-03-05 20:00:53', '', 73, 'http://localhost/Agencia-Fazer/Brasos/73-revision-v1/', 0, 'revision', '', 0),
(156, 1, '2020-03-05 17:01:11', '2020-03-05 20:01:11', '', 'BRASIT 2020', '', 'inherit', 'closed', 'closed', '', '112-revision-v1', '', '', '2020-03-05 17:01:11', '2020-03-05 20:01:11', '', 112, 'http://localhost/Agencia-Fazer/Brasos/112-revision-v1/', 0, 'revision', '', 0),
(157, 1, '2020-03-05 17:01:32', '2020-03-05 20:01:32', '', 'BRASIT 2018', '', 'publish', 'open', 'open', '', 'brasit-2018', '', '', '2020-03-05 18:10:47', '2020-03-05 21:10:47', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=157', 0, 'post', '', 0),
(158, 1, '2020-03-05 17:01:32', '2020-03-05 20:01:32', '', 'BRASIT 2018', '', 'inherit', 'closed', 'closed', '', '157-revision-v1', '', '', '2020-03-05 17:01:32', '2020-03-05 20:01:32', '', 157, 'http://localhost/Agencia-Fazer/Brasos/157-revision-v1/', 0, 'revision', '', 0),
(159, 1, '2020-03-05 17:02:23', '2020-03-05 20:02:23', '', 'BRASIT 2018 (post)', '', 'publish', 'closed', 'closed', '', '159', '', '', '2020-03-05 18:17:33', '2020-03-05 21:17:33', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=159', 3, 'nav_menu_item', '', 0),
(160, 1, '2020-03-05 17:02:23', '2020-03-05 20:02:23', '', 'BRASIT 2020 (post)', '', 'publish', 'closed', 'closed', '', '160', '', '', '2020-03-05 18:17:33', '2020-03-05 21:17:33', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=160', 1, 'nav_menu_item', '', 0),
(161, 1, '2020-03-05 17:02:23', '2020-03-05 20:02:23', '', 'BRASOStbt 2019 (post)', '', 'publish', 'closed', 'closed', '', '161', '', '', '2020-03-05 18:17:33', '2020-03-05 21:17:33', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=161', 2, 'nav_menu_item', '', 0),
(162, 1, '2020-03-05 17:08:46', '2020-03-05 20:08:46', '', 'Brasos2019 - Certificados', '', 'inherit', 'closed', 'closed', '', '147-autosave-v1', '', '', '2020-03-05 17:08:46', '2020-03-05 20:08:46', '', 147, 'http://localhost/Agencia-Fazer/Brasos/147-autosave-v1/', 0, 'revision', '', 0),
(185, 1, '2020-03-05 18:05:19', '2020-03-05 21:05:19', '', 'Brasos2019 - Informações Gerais', '', 'inherit', 'closed', 'closed', '', '133-autosave-v1', '', '', '2020-03-05 18:05:19', '2020-03-05 21:05:19', '', 133, 'http://localhost/Agencia-Fazer/Brasos/133-autosave-v1/', 0, 'revision', '', 0),
(186, 1, '2020-03-05 18:05:54', '2020-03-05 21:05:54', '', 'Eventos', '', 'inherit', 'closed', 'closed', '', '25-autosave-v1', '', '', '2020-03-05 18:05:54', '2020-03-05 21:05:54', '', 25, 'http://localhost/Agencia-Fazer/Brasos/25-autosave-v1/', 0, 'revision', '', 0),
(188, 1, '2020-03-05 18:09:54', '2020-03-05 21:09:54', '', 'BRASOStbt 2019', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2020-03-05 18:09:54', '2020-03-05 21:09:54', '', 73, 'http://localhost/Agencia-Fazer/Brasos/73-revision-v1/', 0, 'revision', '', 0),
(189, 1, '2020-03-05 18:17:33', '2020-03-05 21:17:33', '', 'BRASOStbt 2019', '', 'publish', 'closed', 'closed', '', 'brasostbt-2019', '', '', '2020-03-05 18:17:33', '2020-03-05 21:17:33', '', 0, 'http://localhost/Agencia-Fazer/Brasos/?p=189', 4, 'nav_menu_item', '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_termmeta`
--

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

-- --------------------------------------------------------

--
-- Structure de la table `wp_terms`
--

CREATE TABLE `wp_terms` (
  `term_id` bigint UNSIGNED NOT NULL,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_terms`
--

INSERT INTO `wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Evento', 'evento', 0),
(2, 'menu-header', 'menu-header', 0),
(3, 'menu-footer', 'menu-footer', 0),
(4, 'flag', 'flag', 0),
(5, 'subnav-institucional', 'subnav-institucional', 0),
(6, 'Noticia', 'noticia', 0),
(7, 'Artigo', 'artigo', 0),
(8, 'Congresso', 'congresso', 0),
(9, 'Certificado', 'certificado', 0),
(10, 'midia-social', 'midia-social', 0),
(11, 'nav-brasos2019', 'nav-brasos2019', 0),
(12, 'subnav-eventos', 'subnav-eventos', 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_term_relationships`
--

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 6, 0),
(28, 2, 0),
(29, 2, 0),
(41, 4, 0),
(42, 4, 0),
(43, 2, 0),
(44, 5, 0),
(45, 5, 0),
(46, 5, 0),
(58, 6, 0),
(60, 6, 0),
(62, 6, 0),
(64, 6, 0),
(66, 6, 0),
(73, 1, 0),
(77, 7, 0),
(80, 8, 0),
(90, 6, 0),
(102, 7, 0),
(105, 7, 0),
(112, 1, 0),
(116, 3, 0),
(117, 3, 0),
(118, 3, 0),
(119, 3, 0),
(120, 3, 0),
(121, 3, 0),
(122, 9, 0),
(129, 10, 0),
(149, 11, 0),
(150, 11, 0),
(151, 11, 0),
(152, 11, 0),
(153, 11, 0),
(154, 5, 0),
(157, 1, 0),
(159, 12, 0),
(160, 12, 0),
(161, 12, 0),
(189, 12, 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_term_taxonomy`
--

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint UNSIGNED NOT NULL,
  `term_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_term_taxonomy`
--

INSERT INTO `wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'nav_menu', '', 0, 3),
(3, 3, 'nav_menu', '', 0, 6),
(4, 4, 'nav_menu', '', 0, 2),
(5, 5, 'nav_menu', '', 0, 4),
(6, 6, 'category', '', 0, 7),
(7, 7, 'category', '', 0, 3),
(8, 8, 'category', '', 0, 1),
(9, 9, 'category', '', 0, 1),
(10, 10, 'nav_menu', '', 0, 1),
(11, 11, 'nav_menu', '', 0, 5),
(12, 12, 'nav_menu', '', 0, 4);

-- --------------------------------------------------------

--
-- Structure de la table `wp_trp_dictionary_pt_br_en_us`
--

CREATE TABLE `wp_trp_dictionary_pt_br_en_us` (
  `id` bigint NOT NULL,
  `original` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `translated` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `status` int DEFAULT '0',
  `block_type` int DEFAULT '0',
  `original_id` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_trp_dictionary_pt_br_en_us`
--

INSERT INTO `wp_trp_dictionary_pt_br_en_us` (`id`, `original`, `translated`, `status`, `block_type`, `original_id`) VALUES
(1, 'Home', '', 0, 0, 1),
(2, 'Institucional', 'Institutional', 2, 0, 2),
(3, 'Brasos', '', 0, 0, 3),
(4, 'Estatuo Abeti', '', 0, 0, 4),
(5, 'Palavras do Presidente', '', 0, 0, 5),
(6, 'Conselho Diretor', '', 0, 0, 6),
(7, 'Eventos', 'Events', 2, 0, 7),
(8, 'Artigos', 'Articles', 2, 0, 8),
(9, 'Contato', 'Contact', 2, 0, 9),
(10, 'Torne-se membro', 'Become a member', 2, 0, 10),
(11, 'Estatuto Abeti', '', 0, 0, 11),
(12, 'BRASOS', '', 0, 0, 12),
(13, 'Brazilian Society for Osteoarthritis, Osteoporosis and Sarcopenia -', '', 0, 0, 13),
(14, 'Sociedade de médicos de diferentes especialidades', '', 0, 0, 14),
(15, 'Cursos pré-simpósio de Injeções intra-articulares guiadas por Ultrassonografia em Osteoartrite do Joelho,\n            Quadril, Ombro e Tornozelo.', '', 0, 0, 15),
(16, 'Tratamento por injeções intra-articulares: Ácido Hialurônico em diferentes pesos moleculares, Hialuronato e\n            Ácido Hialurônico associado à outras moléculas Glicocorticóides regulares e de liberação prolongada. Novas\n            moléculas', '', 0, 0, 16),
(17, 'Fatores que potencializam as infiltrações articulares: Colágenos (Natural – Hidrolisados –\n            Ultra-hidrolisados) - Suplementos Adjuvantes – Sysadoa (Sulfato de Condroitina e Glicosamina de alta\n            qualidade – Curcumina – Diacereína) – Prebióticos - Probióticos', '', 0, 0, 17),
(18, 'Tratamento por infiltração na Rede Pública, é possível? Exemplo do municipio de Caraguatatuba.', 'Treatment for infiltration in the public network, is it possible? Example of the municipality of Caraguatatuba.', 2, 0, 18),
(19, 'Viscossuplementação na Agência Nacional de Saúde Suplementar', 'Viscosupplementation at the National Agency for Supplementary Health', 2, 0, 19),
(20, 'Viscossuplementação e Farmacoeconomia', 'Viscossuplementation and Pharmacoeconomics', 2, 0, 20),
(21, 'Consenso Brasileiro sobre Viscossuplementação de Joelho – COBRAVI J: Qual seu legado?', 'Brazilian Consensus on Knee Viscosupplementation - COBRAVI J: What is your legacy?', 2, 0, 21),
(22, 'Consenso Brasileiro sobre Viscossuplementação de Quadril – COBRAVI Q: Apresentação.', 'Brazilian Consensus on Hip Viscossupplementation - COBRAVI Q: Presentation.', 2, 0, 22),
(23, 'Consenso Brasileiro sobre Viscossuplementação de Ombro – COBRAVI O: Realização.', 'Brazilian Consensus on Shoulder Viscosupplementation - COBRAVI O: Achievement.', 2, 0, 23),
(24, 'Uso do Ácido Hialurônico em partes moles', 'Use of hyaluronic acid in soft tissues', 2, 0, 24),
(25, 'Fatores que potencializam as infiltrações articulares: Colágenos - Suplmentos Adjuvantes - Sysadoa', 'Factors Potentiating Joint Infiltrations: Collagen - Adjuvant Supplements - Sysadoa', 2, 0, 25),
(26, 'Novas moléculas no tratamento por infiltração: BM7 - Lubricin - LMWF-5A - betaNGFantibody - Interleukin 1\n            antagonist and antibody receptor - TPX100MEB - PTHrP - TGF-B inhibitor - IARArORa', 'New molecules in infiltration treatment: BM7 - Lubricin - LMWF-5A - betaNGFantibody - Interleukin 1 antagonist and antibody receptor - TPX100MEB - PTHrP - TGF-B inhibitor - IARArORa', 2, 0, 26),
(27, 'Tratamento intra-articular e combinação de moléculas: riscos e beneficios', 'Intra-articular Treatment and Molecular Combination: Risks and Benefits', 2, 0, 27),
(28, 'Tratamento biológico intra-articular: PRP, PRF, CÉLULAS TRONCO – aspirado de medula óssea; fatores de\n            crescimento; células mesenquimais e regenerativas autólogas derivadas do tecido adiposo', 'Intra-articular biological treatment: PRP, PRF, BODY CELLS - bone marrow aspirate; growth factors; autologous mesenchymal and regenerative cells derived from adipose tissue.', 2, 0, 28),
(29, 'Notícias', 'News', 2, 0, 29),
(30, 'Noticias', 'News', 2, 0, 30),
(31, 'Congressos', 'Congress', 2, 0, 31),
(32, 'Sobre a Brasos', '', 0, 0, 32),
(33, 'A BRASOS (Brazilian Society for Osteoarthritis, Osteoporosis and Sarcopenia) é uma sociedade de médicos de\n        diferentes especialidades, fundada em outubro de 2017, com o nome de ABETI (Associação Brasileira para Estudos\n        dos Tratamentos por Infiltração).', 'The BRASOS  (Brazilian Society for Osteoarthritis, Osteoporosis and Sarcopenia) is a society of physicians of different specialties, founded in October 2017, under the name ABETI (Brazilian Association for the Study of Infiltration Treatments).', 2, 0, 33),
(34, 'Saiba Mais', '', 0, 0, 34),
(35, 'Faça Parte da Nossa Comunidade', 'Join Our Community', 2, 0, 35),
(36, 'Torne-se Membro', 'Become a member', 2, 0, 36),
(37, 'A Brasos', '', 0, 0, 37),
(38, 'Brasit 2020', '', 0, 0, 38),
(39, 'Congresso', 'Congress', 2, 0, 39),
(40, 'Certificados', '', 0, 0, 40),
(41, 'Responsável Técnico', '', 0, 0, 41),
(42, 'Antonio Martins Tieppo', '', 0, 0, 42),
(43, 'Primeiro Secretário', '', 0, 0, 43),
(44, 'CRM/SP: 47.777', '', 0, 0, 44),
(45, 'secretario@brasos.med.br', '', 0, 0, 45),
(46, 'Copyright@ 2020. Agência Fazer', '', 0, 0, 46),
(47, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/logo.png', '', 0, 0, 47),
(48, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/flag/brazil.png', '', 0, 0, 48),
(49, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/flag/usa.png', '', 0, 0, 49),
(50, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/d.1.jpg', '', 0, 0, 50),
(51, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/d.2.jpg', '', 0, 0, 51),
(52, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/d.3.jpg', '', 0, 0, 52),
(53, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/card-1.jpg', '', 0, 0, 53),
(54, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/card-4.jpg', '', 0, 0, 54),
(55, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/card-3.jpg', '', 0, 0, 55),
(56, 'width:40px', '', 0, 0, 56),
(57, 'Torne-se membro da Brasos!', '', 0, 0, 57),
(58, 'Faça parte de uma comunidade de profissionais de medicina com a mesma mentalidade: atualização, aplicação\n        prática e pesquisa de novas tecnologias no tratamento da atividade inflamatória descontrolada, através de\n        técnicas guiadas de injeção e infiltração de moléculas reguladoras dos processos metabólicos envolvidos na\n        doença osteoartrítica.', '', 0, 0, 58),
(59, 'A ABETI dá-lhe a oportunidade de se tornar parte de uma comunidade de clínicos e pesquisadores especializados e\n        dedicados a melhorar a vida de milhões de pessoas afetadas pela osteoartrite (OA).', '', 0, 0, 59),
(60, 'A ABETI pode ajudá-lo a fazer conexões benéficas com indivíduos e organizações em todo o mundo que estão na\n        vanguarda da pesquisa, conhecimento e experiência em OA.', '', 0, 0, 60),
(61, 'Compartilhar pesquisa, ideias e resultados.', '', 0, 0, 61),
(62, 'Oportunidade de servir em comitês e forças-tarefa da ABETI para ajudar a desenvolver novas iniciativas e\n        diretrizes.', '', 0, 0, 62),
(63, 'Desconto na inscrição nas atividades científicas como Simpósios e Congressos da ABETI.', '', 0, 0, 63),
(64, 'Para tornar-se membro,preencha o cadastro abaixo:', '', 0, 0, 64),
(65, 'Tornar-se membro', '', 0, 0, 65),
(66, 'Enviar', '', 0, 0, 66),
(67, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/contact.jpg', '', 0, 0, 67),
(68, 'Nome completo', '', 0, 0, 68),
(69, 'Email', '', 0, 0, 69),
(70, 'Telefone', '', 0, 0, 70),
(71, 'Mensagem', '', 0, 0, 71),
(72, 'Titulo da noticia mais recente', '', 0, 0, 72),
(73, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.', '', 0, 0, 73),
(74, 'Noticia 1', '', 0, 0, 74),
(75, 'Noticia 2', '', 0, 0, 75),
(76, 'Noticia 3', '', 0, 0, 76),
(77, 'Noticia 4', '', 0, 0, 77),
(78, 'Noticia 5', '', 0, 0, 78),
(79, 'Noticia 6', '', 0, 0, 79),
(80, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/articles.jpg', '', 0, 0, 80),
(81, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.1-scaled.jpg', '', 0, 0, 81),
(82, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.2-scaled.jpg', '', 0, 0, 82),
(83, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.3-scaled.jpg', '', 0, 0, 83),
(84, 'Artigo 1', '', 0, 0, 84),
(85, 'Dúvidas?', '', 0, 0, 85),
(86, 'Utilize o formulário abaixo para entrar em contato com nossa equipe!', '', 0, 0, 86),
(87, 'Assunto', '', 0, 0, 87),
(88, 'Evento 1', '', 0, 0, 88),
(89, 'Subtitulo', '', 0, 0, 89),
(90, 'BRASIT 2020', '', 0, 0, 90),
(91, 'BRASOStbt 2019', '', 0, 0, 91),
(92, 'BRASIT 2018', '', 0, 0, 92),
(93, 'Cursos pré-simpósio de Injeções intra-articulares guiadas por Ultrassonografia em Osteoartrite do Joelho,\n Quadril, Ombro e Tornozelo.', 'Pre-symposium courses on intra-articular injections guided by ultrasound in knee, hip, shoulder and ankle osteoarthritis.', 2, 0, 93),
(94, 'Tratamento por injeções intra-articulares: Ácido Hialurônico em diferentes pesos moleculares, Hialuronato e Ácido Hialurônico associado à outras moléculas Glicocorticóides regulares e de liberação prolongada. Novas\n moléculas', 'Treatment by intra-articular injections: Hyaluronic Acid in different molecular weights, Hyaluronate and Hyaluronic Acid associated with other molecules Regular and prolonged-release glucocorticoids.\nNew molecules', 2, 0, 94),
(95, 'Fatores que potencializam as infiltrações articulares: Colágenos (Natural –Hidrolisados –\nUltra-hidrolisados) - Suplementos Adjuvantes – Sysadoa (Sulfato de Condroitina e Glicosamina de alta\nqualidade – Curcumina – Diacereína) – Prebióticos - Probióticos', 'Factors that potentiate joint infiltrations: Collagen (Natural - Hydrolyzed - Ultra-hydrolyzed) - Adjuvant Supplements - Sysadoa (Chondroitin Sulfate and High Quality Glycosamine - Curcumin - Diacerein) - Prebiotics - Probiotics', 2, 0, 95),
(96, 'Congresso 1', '', 0, 0, 96),
(97, 'ISIAT 2019', '', 0, 0, 97),
(98, 'Local: Lisboa - Portugal', '', 0, 0, 98),
(99, 'Data: 03 a 05 de outubro de 2019', '', 0, 0, 99),
(100, '31º CONGRESSO BRASILEIRO DE\n              MEDICINA\n              DO\n              EXERCÍCIO E DO ESPORTE E O XI CONGRESSO SUL-AMERICANO DE MEDICINA DO ESPORTE', '', 0, 0, 100),
(101, 'Local: Bourbon Convention - Foz do Iguaçu, PR - Brasil', '', 0, 0, 101),
(102, 'Data: 29 a 31 de agosto de 2019', '', 0, 0, 102),
(103, 'XXXVI CONGRESSO BRASILEIRO DE\n              REUMATOLOGIA', '', 0, 0, 103),
(104, 'Local: Fortaleza, CE - Brasil', '', 0, 0, 104),
(105, 'Data: 04 a 07 de setembro de 2019', '', 0, 0, 105),
(106, 'EULAR ANNUAL CONGRESS 2019', '', 0, 0, 106),
(107, 'Local: Madrid - Espanha', '', 0, 0, 107),
(108, 'Data: 12 a 15 de junho de 2019', '', 0, 0, 108),
(109, 'XXV CONGRESSO BRASILEIRO DE\n              TRAUMA\n              ORTOPÉDICO', '', 0, 0, 109),
(110, 'Local: Curitiba, PR - Brasil', '', 0, 0, 110),
(111, 'Data: 09 a 11 de maio de 2019', '', 0, 0, 111),
(112, 'OARSI 2019 WORLD CONGRESS', '', 0, 0, 112),
(113, 'Local: Toronto, ON - Canada', '', 0, 0, 113),
(114, 'Data: 02 a 05 de maio de 2019', '', 0, 0, 114),
(115, 'https://www.isiat2019.com/', '', 0, 0, 115),
(116, 'http://www.medicinadoesporte.org.br/', '', 0, 0, 116),
(117, 'https://www.reumatologia.org.br/', '', 0, 0, 117),
(118, 'https://oarsi.org/', '', 0, 0, 118),
(119, 'https://www.linkedin.com/company/brasos/', '', 0, 0, 119),
(120, 'Artigo 3', '', 0, 0, 120),
(121, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed...', '', 0, 0, 121),
(122, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis&#8230;', '', 0, 0, 122),
(123, 'Artigo 2', '', 0, 0, 123),
(124, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a Lorem ipsum dolor&#8230;', '', 0, 0, 124),
(125, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/jc-gellidon-uhXlRnt9dTw-unsplash-scaled.jpg', '', 0, 0, 125),
(126, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a', '', 0, 0, 126),
(127, 'CERTIFICADOS', '', 0, 0, 127),
(128, 'BRASIT 2018 - BRASOStbt 2019', '', 0, 0, 128),
(129, 'Por favor, digite seu nome para acessar os certificados disponíveis.', '', 0, 0, 129),
(130, 'NOME COMPLETO', '', 0, 0, 130),
(131, 'Certificado de Desenvolvimento Web', '', 0, 0, 131),
(132, 'Clique para fazer download', '', 0, 0, 132),
(133, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/certificate_icon.png', '', 0, 0, 133),
(134, 'Search...', '', 0, 0, 134);

-- --------------------------------------------------------

--
-- Structure de la table `wp_trp_gettext_en_us`
--

CREATE TABLE `wp_trp_gettext_en_us` (
  `id` bigint NOT NULL,
  `original` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `translated` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `domain` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `status` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_trp_gettext_en_us`
--

INSERT INTO `wp_trp_gettext_en_us` (`id`, `original`, `translated`, `domain`, `status`) VALUES
(1, 'words', '', 'default', 0),
(2, 'Edit My Profile', '', 'default', 0),
(3, 'Log Out', '', 'default', 0),
(4, 'Search', '', 'default', 0),
(5, 'Howdy, %s', '', 'default', 0),
(6, 'About WordPress', '', 'default', 0),
(7, 'WordPress.org', '', 'default', 0),
(8, 'https://wordpress.org/', '', 'default', 0),
(9, 'Documentation', '', 'default', 0),
(10, 'https://codex.wordpress.org/', '', 'default', 0),
(11, 'Support', '', 'default', 0),
(12, 'https://wordpress.org/support/', '', 'default', 0),
(13, 'Feedback', '', 'default', 0),
(14, 'https://wordpress.org/support/forum/requests-and-feedback', '', 'default', 0),
(15, 'Dashboard', '', 'default', 0),
(16, 'Themes', '', 'default', 0),
(17, 'Menus', '', 'default', 0),
(18, 'Customize', '', 'default', 0),
(19, '%s Comments in moderation', '', 'default', 0),
(20, 'User', '', 'default', 0),
(21, 'New', '', 'default', 0),
(22, 'Skip to toolbar', '', 'default', 0),
(23, 'Toolbar', '', 'default', 0),
(24, 'Continue reading %s', '', 'default', 0),
(25, '(more&hellip;)', '', 'default', 0),
(26, '&#8220;%s&#8221;', '', 'default', 0),
(27, 'Shift-click to edit this element.', '', 'default', 0),
(28, 'This link is not live-previewable.', '', 'default', 0),
(29, 'This form is not live-previewable.', '', 'default', 0),
(30, 'Shift-click to edit this widget.', '', 'default', 0),
(31, 'Click to edit this menu.', '', 'default', 0),
(32, 'Click to edit this widget.', '', 'default', 0),
(33, 'Click to edit the site title.', '', 'default', 0),
(34, 'Click to edit this element.', '', 'default', 0),
(35, '%s is forbidden', '', 'default', 0),
(36, 'Saiba Mais', '', 'textdomain', 0),
(37, 'Torne-se Membro', 'Become a member', 'textdomain', 2),
(38, '%d Theme Update', '', 'default', 0),
(39, 'Custom Link', '', 'default', 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_trp_gettext_pt_br`
--

CREATE TABLE `wp_trp_gettext_pt_br` (
  `id` bigint NOT NULL,
  `original` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `translated` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `domain` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `status` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_trp_gettext_pt_br`
--

INSERT INTO `wp_trp_gettext_pt_br` (`id`, `original`, `translated`, `domain`, `status`) VALUES
(1, 'words', '', 'default', 0),
(2, 'Edit My Profile', 'Editar meu perfil', 'default', 2),
(3, 'Log Out', 'Sair', 'default', 2),
(4, 'Search', 'Pesquisar', 'default', 2),
(5, 'Howdy, %s', 'Olá, %s', 'default', 2),
(6, 'About WordPress', 'Sobre o WordPress', 'default', 2),
(7, 'WordPress.org', '', 'default', 0),
(8, 'https://wordpress.org/', 'https://br.wordpress.org/', 'default', 2),
(9, 'Documentation', 'Documentação', 'default', 2),
(10, 'https://codex.wordpress.org/', 'https://codex.wordpress.org/pt-br:Página_Inicial', 'default', 2),
(11, 'Support', 'Suporte', 'default', 2),
(12, 'https://wordpress.org/support/', 'https://br.wordpress.org/support/', 'default', 2),
(13, 'Feedback', '', 'default', 0),
(14, 'https://wordpress.org/support/forum/requests-and-feedback', '', 'default', 0),
(15, 'Dashboard', 'Painel', 'default', 2),
(16, 'Themes', 'Temas', 'default', 2),
(17, 'Menus', '', 'default', 0),
(18, 'Customize', 'Personalizar', 'default', 2),
(19, '%s Comments in moderation', '%s comentário esperando moderação', 'default', 2),
(20, 'User', 'Usuário', 'default', 2),
(21, 'New', 'Novo', 'default', 2),
(22, 'Skip to toolbar', 'Pular para a barra de ferramentas', 'default', 2),
(23, 'Toolbar', 'Barra de ferramentas', 'default', 2),
(24, 'Error occurred on a non-protected endpoint.', 'Ocorreu um erro em um endpoint não protegido.', 'default', 2),
(25, 'There has been a critical error on your website.', 'Há um erro crítico no seu site.', 'default', 2),
(26, 'https://wordpress.org/support/article/debugging-in-wordpress/', '', 'default', 0),
(27, 'Learn more about debugging in WordPress.', 'Aprenda mais sobre depuração no WordPress.', 'default', 2),
(28, 'WordPress &rsaquo; Error', 'Erro &rsaquo; WordPress', 'default', 2),
(29, 'html_lang_attribute', 'pt-BR', 'default', 2),
(30, 'Continue reading %s', 'Continue lendo %s', 'default', 2),
(31, '(more&hellip;)', '(mais&hellip;)', 'default', 2),
(32, 'Pages', 'Páginas', 'default', 2),
(33, '&#8220;%s&#8221;', '', 'default', 0),
(34, 'Shift-click to edit this element.', 'Segure Shift e clique para editar este elemento.', 'default', 2),
(35, 'This link is not live-previewable.', 'Esse link não pode ser pré-visualizado.', 'default', 2),
(36, 'This form is not live-previewable.', 'Esse formulário não pode ser pré-visualizado.', 'default', 2),
(37, 'Shift-click to edit this widget.', 'Pressione shift e clique para editar este widget.', 'default', 2),
(38, 'Click to edit this menu.', 'Clique para editar este menu.', 'default', 2),
(39, 'Click to edit this widget.', 'Clique para editar este widget.', 'default', 2),
(40, 'Click to edit the site title.', 'Clique para editar o título do site.', 'default', 2),
(41, 'Click to edit this element.', 'Clique para editar este elemento.', 'default', 2),
(42, '%s is forbidden', '%s é proibido', 'default', 2),
(43, 'A Brasos', '', 'textdomain', 0),
(44, 'Saiba Mais', '', 'textdomain', 0),
(45, 'Torne-se Membro', 'Torne-se Membro', 'textdomain', 2),
(46, '%d Theme Update', '%d atualização de temas', 'default', 2),
(47, 'Custom Link', 'Link personalizado', 'default', 2),
(48, 'Edit User', 'Editar usuário', 'default', 2),
(49, 'Support Forums', '', 'default', 0),
(50, '%s comments awaiting moderation', '', 'default', 0),
(51, '%d Plugin Update', '%d atualização de plugin', 'default', 2),
(52, 'Translation Updates', 'Atualizações de tradução', 'default', 2),
(53, 'Sender\'s message was sent successfully', '', 'contact-form-7', 0),
(54, 'Thank you for your message. It has been sent.', '', 'contact-form-7', 0),
(55, 'Sender\'s message failed to send', '', 'contact-form-7', 0),
(56, 'There was an error trying to send your message. Please try again later.', '', 'contact-form-7', 0),
(57, 'Validation errors occurred', '', 'contact-form-7', 0),
(58, 'One or more fields have an error. Please check and try again.', '', 'contact-form-7', 0),
(59, 'Submission was referred to as spam', '', 'contact-form-7', 0),
(60, 'There are terms that the sender must accept', '', 'contact-form-7', 0),
(61, 'You must accept the terms and conditions before sending your message.', '', 'contact-form-7', 0),
(62, 'There is a field that the sender must fill in', '', 'contact-form-7', 0),
(63, 'The field is required.', '', 'contact-form-7', 0),
(64, 'There is a field with input that is longer than the maximum allowed length', '', 'contact-form-7', 0),
(65, 'The field is too long.', '', 'contact-form-7', 0),
(66, 'There is a field with input that is shorter than the minimum allowed length', '', 'contact-form-7', 0),
(67, 'The field is too short.', '', 'contact-form-7', 0),
(68, 'Date format that the sender entered is invalid', '', 'contact-form-7', 0),
(69, 'The date format is incorrect.', '', 'contact-form-7', 0),
(70, 'Date is earlier than minimum limit', '', 'contact-form-7', 0),
(71, 'The date is before the earliest one allowed.', '', 'contact-form-7', 0),
(72, 'Date is later than maximum limit', '', 'contact-form-7', 0),
(73, 'The date is after the latest one allowed.', '', 'contact-form-7', 0),
(74, 'Uploading a file fails for any reason', '', 'contact-form-7', 0),
(75, 'There was an unknown error uploading the file.', '', 'contact-form-7', 0),
(76, 'Uploaded file is not allowed for file type', '', 'contact-form-7', 0),
(77, 'You are not allowed to upload files of this type.', '', 'contact-form-7', 0),
(78, 'Uploaded file is too large', '', 'contact-form-7', 0),
(79, 'The file is too big.', '', 'contact-form-7', 0),
(80, 'Uploading a file fails for PHP error', '', 'contact-form-7', 0),
(81, 'There was an error uploading the file.', '', 'contact-form-7', 0),
(82, 'Number format that the sender entered is invalid', '', 'contact-form-7', 0),
(83, 'The number format is invalid.', '', 'contact-form-7', 0),
(84, 'Number is smaller than minimum limit', '', 'contact-form-7', 0),
(85, 'The number is smaller than the minimum allowed.', '', 'contact-form-7', 0),
(86, 'Number is larger than maximum limit', '', 'contact-form-7', 0),
(87, 'The number is larger than the maximum allowed.', '', 'contact-form-7', 0),
(88, 'Sender doesn\'t enter the correct answer to the quiz', '', 'contact-form-7', 0),
(89, 'The answer to the quiz is incorrect.', '', 'contact-form-7', 0),
(90, 'The code that sender entered does not match the CAPTCHA', '', 'contact-form-7', 0),
(91, 'Your entered code is incorrect.', '', 'contact-form-7', 0),
(92, 'Email address that the sender entered is invalid', '', 'contact-form-7', 0),
(93, 'The e-mail address entered is invalid.', '', 'contact-form-7', 0),
(94, 'URL that the sender entered is invalid', '', 'contact-form-7', 0),
(95, 'The URL is invalid.', '', 'contact-form-7', 0),
(96, 'Telephone number that the sender entered is invalid', '', 'contact-form-7', 0),
(97, 'The telephone number is invalid.', '', 'contact-form-7', 0);

-- --------------------------------------------------------

--
-- Structure de la table `wp_trp_original_meta`
--

CREATE TABLE `wp_trp_original_meta` (
  `meta_id` bigint NOT NULL,
  `original_id` bigint NOT NULL,
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_trp_original_meta`
--

INSERT INTO `wp_trp_original_meta` (`meta_id`, `original_id`, `meta_key`, `meta_value`) VALUES
(1, 36, 'post_parent_id', '8'),
(2, 7, 'post_parent_id', '25'),
(3, 8, 'post_parent_id', '19'),
(4, 9, 'post_parent_id', '12'),
(5, 88, 'post_parent_id', '73'),
(6, 73, 'post_parent_id', '73'),
(7, 31, 'post_parent_id', '71'),
(8, 6, 'post_parent_id', '110'),
(9, 38, 'post_parent_id', '112'),
(10, 120, 'post_parent_id', '105'),
(11, 126, 'post_parent_id', '105');

-- --------------------------------------------------------

--
-- Structure de la table `wp_trp_original_strings`
--

CREATE TABLE `wp_trp_original_strings` (
  `id` bigint NOT NULL,
  `original` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_trp_original_strings`
--

INSERT INTO `wp_trp_original_strings` (`id`, `original`) VALUES
(1, 'Home'),
(2, 'Institucional'),
(3, 'Brasos'),
(4, 'Estatuo Abeti'),
(5, 'Palavras do Presidente'),
(6, 'Conselho Diretor'),
(7, 'Eventos'),
(8, 'Artigos'),
(9, 'Contato'),
(10, 'Torne-se membro'),
(11, 'Estatuto Abeti'),
(12, 'BRASOS'),
(13, 'Brazilian Society for Osteoarthritis, Osteoporosis and Sarcopenia -'),
(14, 'Sociedade de médicos de diferentes especialidades'),
(15, 'Cursos pré-simpósio de Injeções intra-articulares guiadas por Ultrassonografia em Osteoartrite do Joelho,\n            Quadril, Ombro e Tornozelo.'),
(16, 'Tratamento por injeções intra-articulares: Ácido Hialurônico em diferentes pesos moleculares, Hialuronato e\n            Ácido Hialurônico associado à outras moléculas Glicocorticóides regulares e de liberação prolongada. Novas\n            moléculas'),
(17, 'Fatores que potencializam as infiltrações articulares: Colágenos (Natural – Hidrolisados –\n            Ultra-hidrolisados) - Suplementos Adjuvantes – Sysadoa (Sulfato de Condroitina e Glicosamina de alta\n            qualidade – Curcumina – Diacereína) – Prebióticos - Probióticos'),
(18, 'Tratamento por infiltração na Rede Pública, é possível? Exemplo do municipio de Caraguatatuba.'),
(19, 'Viscossuplementação na Agência Nacional de Saúde Suplementar'),
(20, 'Viscossuplementação e Farmacoeconomia'),
(21, 'Consenso Brasileiro sobre Viscossuplementação de Joelho – COBRAVI J: Qual seu legado?'),
(22, 'Consenso Brasileiro sobre Viscossuplementação de Quadril – COBRAVI Q: Apresentação.'),
(23, 'Consenso Brasileiro sobre Viscossuplementação de Ombro – COBRAVI O: Realização.'),
(24, 'Uso do Ácido Hialurônico em partes moles'),
(25, 'Fatores que potencializam as infiltrações articulares: Colágenos - Suplmentos Adjuvantes - Sysadoa'),
(26, 'Novas moléculas no tratamento por infiltração: BM7 - Lubricin - LMWF-5A - betaNGFantibody - Interleukin 1\n            antagonist and antibody receptor - TPX100MEB - PTHrP - TGF-B inhibitor - IARArORa'),
(27, 'Tratamento intra-articular e combinação de moléculas: riscos e beneficios'),
(28, 'Tratamento biológico intra-articular: PRP, PRF, CÉLULAS TRONCO – aspirado de medula óssea; fatores de\n            crescimento; células mesenquimais e regenerativas autólogas derivadas do tecido adiposo'),
(29, 'Notícias'),
(30, 'Noticias'),
(31, 'Congressos'),
(32, 'Sobre a Brasos'),
(33, 'A BRASOS (Brazilian Society for Osteoarthritis, Osteoporosis and Sarcopenia) é uma sociedade de médicos de\n        diferentes especialidades, fundada em outubro de 2017, com o nome de ABETI (Associação Brasileira para Estudos\n        dos Tratamentos por Infiltração).'),
(34, 'Saiba Mais'),
(35, 'Faça Parte da Nossa Comunidade'),
(36, 'Torne-se Membro'),
(37, 'A Brasos'),
(38, 'Brasit 2020'),
(39, 'Congresso'),
(40, 'Certificados'),
(41, 'Responsável Técnico'),
(42, 'Antonio Martins Tieppo'),
(43, 'Primeiro Secretário'),
(44, 'CRM/SP: 47.777'),
(45, 'secretario@brasos.med.br'),
(46, 'Copyright@ 2020. Agência Fazer'),
(47, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/logo.png'),
(48, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/flag/brazil.png'),
(49, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/flag/usa.png'),
(50, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/d.1.jpg'),
(51, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/d.2.jpg'),
(52, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/d.3.jpg'),
(53, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/card-1.jpg'),
(54, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/card-4.jpg'),
(55, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/card-3.jpg'),
(56, 'width:40px'),
(57, 'Torne-se membro da Brasos!'),
(58, 'Faça parte de uma comunidade de profissionais de medicina com a mesma mentalidade: atualização, aplicação\n        prática e pesquisa de novas tecnologias no tratamento da atividade inflamatória descontrolada, através de\n        técnicas guiadas de injeção e infiltração de moléculas reguladoras dos processos metabólicos envolvidos na\n        doença osteoartrítica.'),
(59, 'A ABETI dá-lhe a oportunidade de se tornar parte de uma comunidade de clínicos e pesquisadores especializados e\n        dedicados a melhorar a vida de milhões de pessoas afetadas pela osteoartrite (OA).'),
(60, 'A ABETI pode ajudá-lo a fazer conexões benéficas com indivíduos e organizações em todo o mundo que estão na\n        vanguarda da pesquisa, conhecimento e experiência em OA.'),
(61, 'Compartilhar pesquisa, ideias e resultados.'),
(62, 'Oportunidade de servir em comitês e forças-tarefa da ABETI para ajudar a desenvolver novas iniciativas e\n        diretrizes.'),
(63, 'Desconto na inscrição nas atividades científicas como Simpósios e Congressos da ABETI.'),
(64, 'Para tornar-se membro,preencha o cadastro abaixo:'),
(65, 'Tornar-se membro'),
(66, 'Enviar'),
(67, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/contact.jpg'),
(68, 'Nome completo'),
(69, 'Email'),
(70, 'Telefone'),
(71, 'Mensagem'),
(72, 'Titulo da noticia mais recente'),
(73, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.'),
(74, 'Noticia 1'),
(75, 'Noticia 2'),
(76, 'Noticia 3'),
(77, 'Noticia 4'),
(78, 'Noticia 5'),
(79, 'Noticia 6'),
(80, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/articles.jpg'),
(81, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.1-scaled.jpg'),
(82, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.2-scaled.jpg'),
(83, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/d.3-scaled.jpg'),
(84, 'Artigo 1'),
(85, 'Dúvidas?'),
(86, 'Utilize o formulário abaixo para entrar em contato com nossa equipe!'),
(87, 'Assunto'),
(88, 'Evento 1'),
(89, 'Subtitulo'),
(90, 'BRASIT 2020'),
(91, 'BRASOStbt 2019'),
(92, 'BRASIT 2018'),
(93, 'Cursos pré-simpósio de Injeções intra-articulares guiadas por Ultrassonografia em Osteoartrite do Joelho,\n Quadril, Ombro e Tornozelo.'),
(94, 'Tratamento por injeções intra-articulares: Ácido Hialurônico em diferentes pesos moleculares, Hialuronato e Ácido Hialurônico associado à outras moléculas Glicocorticóides regulares e de liberação prolongada. Novas\n moléculas'),
(95, 'Fatores que potencializam as infiltrações articulares: Colágenos (Natural –Hidrolisados –\nUltra-hidrolisados) - Suplementos Adjuvantes – Sysadoa (Sulfato de Condroitina e Glicosamina de alta\nqualidade – Curcumina – Diacereína) – Prebióticos - Probióticos'),
(96, 'Congresso 1'),
(97, 'ISIAT 2019'),
(98, 'Local: Lisboa - Portugal'),
(99, 'Data: 03 a 05 de outubro de 2019'),
(100, '31º CONGRESSO BRASILEIRO DE\n              MEDICINA\n              DO\n              EXERCÍCIO E DO ESPORTE E O XI CONGRESSO SUL-AMERICANO DE MEDICINA DO ESPORTE'),
(101, 'Local: Bourbon Convention - Foz do Iguaçu, PR - Brasil'),
(102, 'Data: 29 a 31 de agosto de 2019'),
(103, 'XXXVI CONGRESSO BRASILEIRO DE\n              REUMATOLOGIA'),
(104, 'Local: Fortaleza, CE - Brasil'),
(105, 'Data: 04 a 07 de setembro de 2019'),
(106, 'EULAR ANNUAL CONGRESS 2019'),
(107, 'Local: Madrid - Espanha'),
(108, 'Data: 12 a 15 de junho de 2019'),
(109, 'XXV CONGRESSO BRASILEIRO DE\n              TRAUMA\n              ORTOPÉDICO'),
(110, 'Local: Curitiba, PR - Brasil'),
(111, 'Data: 09 a 11 de maio de 2019'),
(112, 'OARSI 2019 WORLD CONGRESS'),
(113, 'Local: Toronto, ON - Canada'),
(114, 'Data: 02 a 05 de maio de 2019'),
(115, 'https://www.isiat2019.com/'),
(116, 'http://www.medicinadoesporte.org.br/'),
(117, 'https://www.reumatologia.org.br/'),
(118, 'https://oarsi.org/'),
(119, 'https://www.linkedin.com/company/brasos/'),
(120, 'Artigo 3'),
(121, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed...'),
(122, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis&#8230;'),
(123, 'Artigo 2'),
(124, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a Lorem ipsum dolor&#8230;'),
(125, 'http://localhost/Agencia-Fazer/Brasos/content/uploads/2020/03/jc-gellidon-uhXlRnt9dTw-unsplash-scaled.jpg'),
(126, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi condimentum non neque quis fermentum. Sed facilisis mollis eros a'),
(127, 'CERTIFICADOS'),
(128, 'BRASIT 2018 - BRASOStbt 2019'),
(129, 'Por favor, digite seu nome para acessar os certificados disponíveis.'),
(130, 'NOME COMPLETO'),
(131, 'Certificado de Desenvolvimento Web'),
(132, 'Clique para fazer download'),
(133, 'http://localhost/Agencia-Fazer/Brasos/content/themes/brasos/public/images/certificate_icon.png'),
(134, 'Search...');

-- --------------------------------------------------------

--
-- Structure de la table `wp_usermeta`
--

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_usermeta`
--

INSERT INTO `wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'ocean'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy'),
(15, 1, 'show_welcome_panel', '1'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(19, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:0:{}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(22, 1, 'nav_menu_recently_edited', '12'),
(23, 1, 'trp_new_feature_image_translation_dismiss_notification', 'true'),
(24, 1, 'wp_user-settings', 'libraryContent=browse'),
(25, 1, 'wp_user-settings-time', '1583109122'),
(28, 2, 'nickname', 'new-user'),
(29, 2, 'first_name', 'Helio'),
(30, 2, 'last_name', 'Cruz'),
(31, 2, 'description', ''),
(32, 2, 'rich_editing', 'true'),
(33, 2, 'syntax_highlighting', 'true'),
(34, 2, 'comment_shortcuts', 'false'),
(35, 2, 'admin_color', 'fresh'),
(36, 2, 'use_ssl', '0'),
(37, 2, 'show_admin_bar_front', 'true'),
(38, 2, 'locale', ''),
(39, 2, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(40, 2, 'wp_user_level', '0'),
(41, 2, 'dismissed_wp_pointers', ''),
(47, 3, 'nickname', 'Teste'),
(48, 3, 'first_name', ''),
(49, 3, 'last_name', ''),
(50, 3, 'description', ''),
(51, 3, 'rich_editing', 'true'),
(52, 3, 'syntax_highlighting', 'true'),
(53, 3, 'comment_shortcuts', 'false'),
(54, 3, 'admin_color', 'fresh'),
(55, 3, 'use_ssl', '0'),
(56, 3, 'show_admin_bar_front', 'true'),
(57, 3, 'locale', ''),
(58, 3, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(59, 3, 'wp_user_level', '0'),
(60, 3, 'default_password_nag', '1'),
(62, 4, 'nickname', 'helio-cruz'),
(63, 4, 'first_name', 'Helinho'),
(64, 4, 'last_name', 'Cruz'),
(65, 4, 'description', ''),
(66, 4, 'rich_editing', 'true'),
(67, 4, 'syntax_highlighting', 'true'),
(68, 4, 'comment_shortcuts', 'false'),
(69, 4, 'admin_color', 'fresh'),
(70, 4, 'use_ssl', '0'),
(71, 4, 'show_admin_bar_front', 'true'),
(72, 4, 'locale', ''),
(73, 4, 'wp_capabilities', 'a:1:{s:10:\"subscriber\";b:1;}'),
(74, 4, 'wp_user_level', '0'),
(75, 4, 'dismissed_wp_pointers', ''),
(76, 2, 'session_tokens', 'a:1:{s:64:\"1054b18370b950db53bb6040bc8cc4bb8d8a34b70a64c294201aaaef9cb8dbca\";a:4:{s:10:\"expiration\";i:1583528165;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:104:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36\";s:5:\"login\";i:1583355365;}}'),
(77, 1, 'session_tokens', 'a:2:{s:64:\"63913061872068501ca1244ceeeb059ed954ad097c001e07875a09f9e881cb38\";a:4:{s:10:\"expiration\";i:1583542431;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:104:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36\";s:5:\"login\";i:1583369631;}s:64:\"842dd6d702f14ab2e7f95e17dff5708fb90a185b374e305cb3d4f0c1dbb9d5e4\";a:4:{s:10:\"expiration\";i:1583565936;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:104:\"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36\";s:5:\"login\";i:1583393136;}}');

-- --------------------------------------------------------

--
-- Structure de la table `wp_users`
--

CREATE TABLE `wp_users` (
  `ID` bigint UNSIGNED NOT NULL,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Contenu de la table `wp_users`
--

INSERT INTO `wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$Bt2yLRIEs8QY2T7cFLpN7f0PvBIrcp0', 'admin', 'helio-cruz@hotmail.com', '', '2020-02-07 18:10:19', '', 0, 'admin'),
(2, 'new-user', '$P$BTDeatg.9dL4sWrPfM/RLsEqSK1wkQ0', 'new-user', 'cj.helio@yahoo.fr', '', '2020-03-04 20:05:45', '1583352345:$P$BwEV9cwMwyJW66Cq24L0m98/Gl6PFA0', 0, 'Helio Cruz'),
(3, 'Teste', '$P$BP/NnmkXwihu5r9NfD4ZwWHodWRHr91', 'teste', 'helioxcruz@hotmail.com', '', '2020-03-04 20:38:11', '1583354291:$P$BBaLTCrbUjFx5UnLBfFXFgpCvCLwJ91', 0, 'Teste'),
(4, 'helio-cruz', '$P$BXyl9c6KlD1Fvh4iHxDuICAfjbptyp1', 'helio-cruz', 'helioxcruz@gmail.com', '', '2020-03-04 20:42:01', '1583354521:$P$BXkYXBLbQyPpj00y.TOvp724xo792o.', 0, 'Helinho Cruz');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `wp_advsh`
--
ALTER TABLE `wp_advsh`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `wp_autosuggest`
--
ALTER TABLE `wp_autosuggest`
  ADD PRIMARY KEY (`idindex`);

--
-- Index pour la table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `wp_comments`
--
ALTER TABLE `wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Index pour la table `wp_links`
--
ALTER TABLE `wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Index pour la table `wp_options`
--
ALTER TABLE `wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`),
  ADD KEY `autoload` (`autoload`);

--
-- Index pour la table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `wp_posts`
--
ALTER TABLE `wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Index pour la table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `wp_terms`
--
ALTER TABLE `wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Index pour la table `wp_term_relationships`
--
ALTER TABLE `wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Index pour la table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Index pour la table `wp_trp_dictionary_pt_br_en_us`
--
ALTER TABLE `wp_trp_dictionary_pt_br_en_us`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `index_name` (`original`(100));
ALTER TABLE `wp_trp_dictionary_pt_br_en_us` ADD FULLTEXT KEY `original_fulltext` (`original`);

--
-- Index pour la table `wp_trp_gettext_en_us`
--
ALTER TABLE `wp_trp_gettext_en_us`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `index_name` (`original`(100));
ALTER TABLE `wp_trp_gettext_en_us` ADD FULLTEXT KEY `original_fulltext` (`original`);

--
-- Index pour la table `wp_trp_gettext_pt_br`
--
ALTER TABLE `wp_trp_gettext_pt_br`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `index_name` (`original`(100));
ALTER TABLE `wp_trp_gettext_pt_br` ADD FULLTEXT KEY `original_fulltext` (`original`);

--
-- Index pour la table `wp_trp_original_meta`
--
ALTER TABLE `wp_trp_original_meta`
  ADD PRIMARY KEY (`meta_id`),
  ADD UNIQUE KEY `meta_id` (`meta_id`),
  ADD KEY `index_original_id` (`original_id`),
  ADD KEY `meta_key` (`meta_key`);

--
-- Index pour la table `wp_trp_original_strings`
--
ALTER TABLE `wp_trp_original_strings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_original` (`original`(100));

--
-- Index pour la table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Index pour la table `wp_users`
--
ALTER TABLE `wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `wp_advsh`
--
ALTER TABLE `wp_advsh`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `wp_autosuggest`
--
ALTER TABLE `wp_autosuggest`
  MODIFY `idindex` int NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `wp_commentmeta`
--
ALTER TABLE `wp_commentmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `wp_comments`
--
ALTER TABLE `wp_comments`
  MODIFY `comment_ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT pour la table `wp_links`
--
ALTER TABLE `wp_links`
  MODIFY `link_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `wp_options`
--
ALTER TABLE `wp_options`
  MODIFY `option_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=405;
--
-- AUTO_INCREMENT pour la table `wp_postmeta`
--
ALTER TABLE `wp_postmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=467;
--
-- AUTO_INCREMENT pour la table `wp_posts`
--
ALTER TABLE `wp_posts`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=190;
--
-- AUTO_INCREMENT pour la table `wp_termmeta`
--
ALTER TABLE `wp_termmeta`
  MODIFY `meta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `wp_terms`
--
ALTER TABLE `wp_terms`
  MODIFY `term_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `wp_term_taxonomy`
--
ALTER TABLE `wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT pour la table `wp_trp_dictionary_pt_br_en_us`
--
ALTER TABLE `wp_trp_dictionary_pt_br_en_us`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;
--
-- AUTO_INCREMENT pour la table `wp_trp_gettext_en_us`
--
ALTER TABLE `wp_trp_gettext_en_us`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT pour la table `wp_trp_gettext_pt_br`
--
ALTER TABLE `wp_trp_gettext_pt_br`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
--
-- AUTO_INCREMENT pour la table `wp_trp_original_meta`
--
ALTER TABLE `wp_trp_original_meta`
  MODIFY `meta_id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT pour la table `wp_trp_original_strings`
--
ALTER TABLE `wp_trp_original_strings`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;
--
-- AUTO_INCREMENT pour la table `wp_usermeta`
--
ALTER TABLE `wp_usermeta`
  MODIFY `umeta_id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;
--
-- AUTO_INCREMENT pour la table `wp_users`
--
ALTER TABLE `wp_users`
  MODIFY `ID` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
